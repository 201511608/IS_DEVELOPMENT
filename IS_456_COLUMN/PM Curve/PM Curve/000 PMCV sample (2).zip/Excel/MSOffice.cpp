// MSOffice.cpp: implementation of the CMSOffice class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "excel9.h"
//#include "winable.h"
#include "MSOffice.h"
#include "MSLibFileCtrl.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMSOffice::CMSOffice()
{

}

CMSOffice::~CMSOffice()
{

}


int CMSOffice::GetExcelVersion()
{
	int  nVersion = 0;
	_Application_Excel  oApp;
	if(!oApp.CreateDispatch("Excel.Application", NULL))
	{ 		
		return 0;
	}    
	CString strVersion = oApp.GetVersion();
	oApp.Quit();  
	nVersion = atoi(strVersion);

	return nVersion;
}

int CMSOffice::GetWordVersion()
{	
	CString strWordVer = "";
	int     nVersion = 0;

	CString strCurVer, strAddition = "";
	//CLSID clsid;
	//	LPDISPATCH pDisp;    
	//LPUNKNOWN pUnk;    
	HKEY hKey;
	DWORD lpType, size;
	char *chCurVer;
	//��ע���HKEY_CLASSES_ROOT�е�ǰcad�汾ֵ
	LONG result = RegOpenKeyEx(HKEY_CLASSES_ROOT,
		_T("Word.Application\\CurVer"), NULL,
		KEY_READ|KEY_QUERY_VALUE, &hKey);
	if(result == ERROR_SUCCESS)
	{
		RegQueryValueEx(hKey, _T(""), NULL, &lpType, 0, &size);
		chCurVer = new char[size];
		result = RegQueryValueEx(hKey, _T(""), NULL, &lpType, (BYTE *)chCurVer, &size);
		if(result == ERROR_SUCCESS)
			strCurVer = chCurVer;
		delete[] chCurVer;
		chCurVer = NULL;
		result = RegCloseKey(hKey);
	}
	strCurVer.TrimLeft("Word.Application.");
	//strCurVer.Append(".0");
  //strAddition.Append(strCurVer);
  strCurVer = strCurVer + ".0";
	strAddition = strCurVer;
	strWordVer = strAddition;

	/*
	if (FAILED(::CLSIDFromProgID(L"Word.Application", &clsid))) // from Registry
	{
		return FALSE;
	}
	LPOLESTR pstr=NULL;
	StringFromCLSID(clsid, &pstr); 
	CString regClsid = "CLSID\\";
	CString strWordPath = "";
	regClsid += CString(pstr);
	regClsid += "\\LocalServer32";

	if(!(SUCCEEDED(::GetActiveObject(clsid, NULL, &pUnk))))
	{
		LONG result = RegOpenKeyEx(HKEY_CLASSES_ROOT,
			regClsid, NULL,	KEY_READ|KEY_QUERY_VALUE, &hKey);
		if(result == ERROR_SUCCESS)
		{
			RegQueryValueEx(hKey, _T(""), NULL, &lpType, 0, &size);
			chCurVer = new char[size];
			result = RegQueryValueEx(hKey, _T(""), NULL, &lpType, (BYTE *)chCurVer, &size);
			if(result == ERROR_SUCCESS)
				strWordPath = chCurVer;
			delete[] chCurVer;
			chCurVer = NULL;
			result = RegCloseKey(hKey);
		}
		int n = strWordPath.Find(" ");
		strWordPath = strWordPath.Left(n);


		if(strWordVer == "8.0")
		{
		}
		else
		{
			//		strWordPath = "D:\\PROGRA~1\\MICROS~1\\Office10\\WINWORD.EXE";
			ShellExecute(NULL,NULL,strWordPath,"/n /dde",NULL,SW_SHOWMAXIMIZED);
			int k = 0;
			while(!(SUCCEEDED(::GetActiveObject(clsid, NULL, &pUnk))))
			{
				k++;
				Sleep( 150L );
				if(k > 500)
				{
					::BlockInput(FALSE);
					AfxGetMainWnd()->MessageBox("Wordû������! �޷����ɼ�����","midas/Building");
					return FALSE;
				}
			}

			pUnk->Release();        
		}

	}
	else
	{
		pUnk->Release();        
	}
	*/


	strAddition = "";
	strCurVer = "";
	//��ע���HKEY_CLASSES_ROOT�е�ǰcad�汾ֵ
	result = RegOpenKeyEx(HKEY_CLASSES_ROOT,
		_T("Word.Application\\CurVer"), NULL,
		KEY_READ|KEY_QUERY_VALUE, &hKey);
	if(result == ERROR_SUCCESS)
	{
		RegQueryValueEx(hKey, _T(""), NULL, &lpType, 0, &size);
		chCurVer = new char[size];
		result = RegQueryValueEx(hKey, _T(""), NULL, &lpType, (BYTE *)chCurVer, &size);
		if(result == ERROR_SUCCESS)
			strCurVer = chCurVer;
		delete[] chCurVer;
		chCurVer = NULL;
		result = RegCloseKey(hKey);
	}
	strCurVer.TrimLeft("Word.Application.");
	//strCurVer.Append(".0");
	//strAddition.Append(strCurVer);
  strCurVer = strCurVer + ".0";
	strAddition = strCurVer;
	strWordVer = strAddition;

	nVersion = atoi(strWordVer);
	
	return nVersion;
}

CString CMSOffice::GetExtensionName(int nType)
{
	CString strExtensionName = "";
	if(nType == 1)
	{	
		strExtensionName = "xls";

		int nVersion = GetExcelVersion();

		if(nVersion >= 12)
			strExtensionName = "xlsx";
	}
	else if(nType == 2)
	{
		strExtensionName = "doc";

		int nVersion = GetWordVersion();

		if(nVersion >= 12)
			strExtensionName = "docx";
	}

	return strExtensionName;
}


