// FileCtrl.h: interface for the CFileCtrl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(__MSLIBFILECTRL_H__)
#define __MSLIBFILECTRL_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class  CMSLibFileCtrl
{
public:
	CMSLibFileCtrl();
	CMSLibFileCtrl(LPCTSTR pszFilePathNameExt);        // "c:\midas\gen\gen.exe"
	virtual ~CMSLibFileCtrl();

public:
	void SetFilePathNameExt(LPCTSTR pszFilePathNameExt); // "c:\midas\gen\gen.exe"

	CString GetFilePathNameExt();                   // "c:\midas\gen\gen.exe"
	CString GetFilePathName();                      // "c:\midas\gen\gen"
	CString GetFilePath();                          // "c:\midas\gen\"
	CString GetFileNameExt();                       // "gen.exe"
	CString GetFileName();                          // "gen"
	CString GetFileExt();                           // "exe"
  CString GetAbbPathNameExt(int nMaxLen);              // "c:\...\gen.exe"
  CString GetAbbPathNameExt(CDC* pDC, LPRECT lpRect);  // "c:\...\gen.exe"

	BOOL FileExists();
	BOOL GetFileStatus(CFileStatus& rFileStatus);

  static BOOL CopyFile(LPCTSTR lpszOldName, LPCTSTR lpszNewName);
	BOOL GetFileInfoString(LPTSTR lptstrFilename, LPCTSTR lptstrQuery, CString &strInfo);

protected:
	CString m_strFilePath;
	CString m_strFileName;
	CString m_strFileExt;
};


#endif // !defined(__MSLIBFILECTRL_H__)
