// MSExcel.cpp: implementation of the CMSExcel class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MSExcel.h"
#include "math.h"
#include "MSOffice.h"



#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
ChartData::ChartData()
{
	ChartType = xlXYScatterSmooth;
	PlotBy    = xlColumns;
	bLegend   = TRUE;
	LegendPosition = xlLegendPositionRight;
	color     = 15;
	nXunit    = 0;
	nYunit    = 0;
	dXmax     = 1.0E41;
	dYmax     = 1.0E41;
	dXmin     = -1.0E41;
	dYmin     = -1.0E41;
  nStRow  = 0;  //���� Row
  nStCol  = 0;  //���� Col
  nEdRow  = 0;  //�� Row
  nEdCol  = 0;  //�� Col
}

ChartData::ChartData(ChartData& src)
{
	this->SourceData  = src.SourceData;
	this->bLegend     = src.bLegend;
	this->ChartTitle  = src.ChartTitle;
	this->ChartType   = src.ChartType;
	this->PlotBy      = src.PlotBy;
	this->LegendPosition = src.LegendPosition;
	this->color       = src.color;

	this->xTitle      = src.xTitle;
	this->yTitle      = src.yTitle;
	this->dXmax       = src.dXmax;
	this->dXmin       = src.dXmin;
	this->dYmax       = src.dYmax;
	this->dYmin       = src.dYmin;
	this->nXunit      = src.nXunit;
	this->nYunit      = src.nYunit;

  nStRow  = src.nStRow;
  nStCol  = src.nStCol;
  nEdRow  = src.nEdRow;
  nEdCol  = src.nEdCol;

	this->aSeries.RemoveAll();
	for(int i=0; i<src.aSeries.GetSize(); i++)
	{
		this->aSeries.Add(src.aSeries[i]);
	}
}

ChartData::~ChartData()
{
}

ChartData& ChartData::operator= (const ChartData& src)
{
	this->SourceData  = src.SourceData;
	this->bLegend     = src.bLegend;
	this->ChartTitle  = src.ChartTitle;
	this->ChartType   = src.ChartType;
	this->PlotBy      = src.PlotBy;
	this->LegendPosition = src.LegendPosition;
	this->color       = src.color;

	this->xTitle      = src.xTitle;
	this->yTitle      = src.yTitle;
	this->dXmax       = src.dXmax;
	this->dXmin       = src.dXmin;
	this->dYmax       = src.dYmax;
	this->dYmin       = src.dYmin;
	this->nXunit      = src.nXunit;
	this->nYunit      = src.nYunit;

	this->aSeries.RemoveAll();
	for(int i=0; i<src.aSeries.GetSize(); i++)
	{
		this->aSeries.Add(src.aSeries[i]);
	}

	return *this;
}

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMSExcel::CMSExcel(int nType, BOOL bExcelRun, BOOL bRowNumOut, BOOL bColumnNumOut, int nRangeCount)
{
	// Text ��Ͻ� ///////////////////////////////////////////
	m_nRecDefaultRangeCount = nRangeCount;
	m_nRecType = nType;
	m_bRecExcelRun = bExcelRun;
	m_WorkRec.Initialize(nType, bRowNumOut, bColumnNumOut);
	if(!m_bRecExcelRun) return;
	// CMSExcel�� �۾��� �����Ŵ
	//
	// Excel�� �����Ű�� ������ 
	// CopyRange�۾��� Range�� ũ�⸦ �˼� ���� ������ 
	// Excel����, Quit, Open, Close�۾��� �����ϰ� ���� ��Ŵ
	//
	// nType==1 �����̾ Book �� Sheet�� �̸��� �ʿ��ϹǷ� 
	// nType==1,2 ��� m_WorkRec�� ������ ������
	//
	//////////////////////////////////////////////////////////

//    _Application_Excel oApp;
	vTrue = COleVariant((short)TRUE);
	vFalse = COleVariant((short)FALSE);
	vOpt = COleVariant((long)DISP_E_PARAMNOTFOUND, VT_ERROR);
/*Thread�� ������ �����۾� �����ϴ� ���� ������ ��
	if(!AfxOleInit())
	{
		AfxMessageBox("Could not initialize COM dll");
		return;
	}
//*/

	if(!oApp.CreateDispatch("Excel.Application", NULL))
	{       
		m_bXL = FALSE;
//		AfxMessageBox("Cannot start Excel");	
		return;
	}    
	m_bXL = TRUE;

  ////////////////////////////////////////////////////////////////////////////////////
  //COleMessageFilter* pFilter = AfxOleGetMessageFilter(); 
  //pFilter->SetMessagePendingDelay(10000);      // Default�� 5000ms�Դϴ�. 
  //pFilter->EnableBusyDialog(FALSE);            // �޼����ڽ��� ȭ�鿡 ��Ÿ���� ���� �ʰ� �մϴ�.
  //pFilter->EnableNotRespondingDialog(FALSE); 
	//pFilter->SetMessagePendingDelay(10000);      // Default�� 5000ms�Դϴ�. 
  //pFilter->EnableBusyDialog(FALSE);            // �޼����ڽ��� ȭ�鿡 ��Ÿ���� ���� �ʰ� �մϴ�.  
  ////////////////////////////////////////////////////////////////////////////////////

  //Start a new workbook
	LPDISPATCH lpDisp;
	lpDisp = oApp.GetWorkbooks();
	ASSERT(lpDisp);
	oBooks.AttachDispatch(lpDisp);
	ASSERT(lpDisp);
	oApp.SetDisplayAlerts(FALSE);	//Ȯ�� ��ȭ���ڸ� �����ʰ� ����

	lpDisp = oApp.GetWindows();
	ASSERT(lpDisp);
	oWindows.AttachDispatch(lpDisp);	

	m_ExcelVer = oApp.GetVersion();
}

CMSExcel::~CMSExcel()
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��		
		// CMSExcel�� �۾��� �����Ŵ
		if(!m_bRecExcelRun) return;
	}
	//////////////////////////////////

//  oBooks.Close();
//	oApp.Quit();  
}

//  XlWindowState : xlMaximized, xlMinimized, xlNormal
void CMSExcel::SetWindowState(XlWindowState wdState)
{
	// Text ��� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { m_WorkRec.Add_WorkHistory("SetWindowState"); }		
		// CMSExcel�� �۾��� �����Ŵ
		if(!m_bRecExcelRun) return;
	}
	oApp.SetWindowState(wdState);
}

void CMSExcel::Quit()
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		m_WorkRec.Initialize(0);
		if(!m_bRecExcelRun) return;
		// CMSExcel�� �۾��� �����Ŵ
	}
	//////////////////////////////////

//	oBook.Close(vFalse,vOpt,vOpt);
//	oApp.ReleaseDispatch();
  ReleaseBeforeSave();

  if(oBooks.m_lpDispatch)
  {
    oBooks.Close();
    oBooks.ReleaseDispatch();
  }  
  
  if(oApp.m_lpDispatch)
  {
    oApp.Quit();
    oApp.ReleaseDispatch();
  }
}

//ex) sFilename - C:\\WORK\\test3.xls
void CMSExcel::Open(CString sFilename)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;  strTemp.Format("Open:%s", sFilename);  m_WorkRec.Add_WorkHistory(strTemp); }	
		if(!m_bRecExcelRun) return;
		// CMSExcel�� �۾��� �����Ŵ
	}
	//////////////////////////////////

	LPDISPATCH lpDisp;
	lpDisp = oBooks.Open(sFilename,vOpt,vOpt,vOpt,vOpt,vOpt,vOpt,vOpt,vOpt,vOpt,vOpt,vOpt,vOpt);
	ASSERT(lpDisp);
	oBook.AttachDispatch(lpDisp);
	oApp.SetDisplayAlerts(FALSE);	//Ȯ�� ��ȭ���ڸ� �����ʰ� ����

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
  oSheets.AttachDispatch(lpDisp);

	lpDisp = oSheets.GetItem(COleVariant((long)1));
	ASSERT(lpDisp);
	oSheet.AttachDispatch(lpDisp);
}

void CMSExcel::Close(CString sFilename)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;  strTemp.Format("Close:%s", sFilename);  m_WorkRec.Add_WorkHistory(strTemp); }		
		if(!m_bRecExcelRun) return;
		// CMSExcel�� �۾��� �����Ŵ
	}
	//////////////////////////////////

	SetActiveBook(sFilename);
	if(oBook.m_lpDispatch)
  {
    oBook.Close(vOpt, COleVariant(sFilename), vOpt);  
    oBook.ReleaseDispatch();
  }
}

void CMSExcel::Close()
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { m_WorkRec.Add_WorkHistory("Close"); }		
		if(!m_bRecExcelRun) return;
		// CMSExcel�� �۾��� �����Ŵ
	}
	//////////////////////////////////

  if(oBooks.m_lpDispatch)
  {
    oBooks.Close();
    oBooks.ReleaseDispatch();
  }	
}

CString CMSExcel::SaveAs(CString sBookName, CString sFilename, CString strFileFormat)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;  strTemp.Format("SaveAs:%s", sFilename);  m_WorkRec.Add_WorkHistory(strTemp); }		
		m_WorkRec.TextOut(sFilename, sBookName);
		return sFilename; // CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

  oBook = oBooks.GetItem(COleVariant(sBookName));
	//oBook.SetSaved(TRUE);

  VARIANT varFileFormat = vOpt;
  if(!strFileFormat.IsEmpty()) varFileFormat = COleVariant(strFileFormat);

	try
	{
		oBook.SaveAs(COleVariant(sFilename),varFileFormat,vOpt,vOpt,vOpt,vOpt,0,vOpt,vOpt,vOpt,vOpt);
	}
	catch(CException* e)
	{
		int nF = sFilename.Find(".");
		CString sT = sFilename.Left(nF);

		//sFilename = sT + "_bak"+".xls";
    CString strExtension = GetExtensionName();
    sFilename = sFilename + "_bak"+"."+strExtension; // file name�� Ȯ���ڰ� �Ⱥپ��.

		CString sMsg;
		//sMsg = sFilename + "�� �����մϴ�."; // Check!!! ���ڿ� ó��
    sMsg.Format("Saved as %s.",sFilename);
		//AfxMessageBox(sFilename);
    AfxMessageBox(sMsg);

		oBook.SaveAs(COleVariant(sFilename),varFileFormat,vOpt,vOpt,vOpt,vOpt,0,vOpt,vOpt,vOpt,vOpt);

		e->Delete();
	}
	catch(...)
	{
	}
	return sFilename;

//SaveAs(const VARIANT& Filename, const VARIANT& FileFormat, const VARIANT& Password, const VARIANT& WriteResPassword,
//const VARIANT& ReadOnlyRecommended, const VARIANT& CreateBackup, long AccessMode, const VARIANT& ConflictResolution, 
//const VARIANT& AddToMru, const VARIANT& TextCodepage, const VARIANT& TextVisualLayout)
}

void CMSExcel::Save(CString sBookName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;  strTemp.Format("Save:%s", sBookName);  m_WorkRec.Add_WorkHistory(strTemp); }		
		m_WorkRec.TextOut(sBookName, sBookName);
		return; // CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

  oBook = oBooks.GetItem(COleVariant(sBookName));
  try
  {
    oBook.Save();
  }
  catch(CException* e)
  {
    AfxMessageBox("������ �� �����ϴ�.");
    e->Delete();
  }
  catch(...)
  {
  }
}

void CMSExcel::AddBook()
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { m_WorkRec.Add_WorkHistory("AddBook"); }
		m_WorkRec.Add_Book("", TRUE); 
		if(!m_bRecExcelRun) return;
		// CMSExcel�� �۾��� �����Ŵ
	}
	//////////////////////////////////


	LPDISPATCH lpDisp;

	lpDisp = oBooks.Add(vOpt);
	ASSERT(lpDisp);
	oBook.AttachDispatch(lpDisp);
}

CString CMSExcel::GetExtensionName()
{	
	double  dVersion   = atof(m_ExcelVer);
	if(dVersion >= 12.0) return "xlsx";
	return "xls";
}
int CMSExcel::GetExcelVersion()
{
	return atoi(m_ExcelVer);
}

//Sheet�� �� �տ� ����
void CMSExcel::AddSheet(CString sSheetName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;  strTemp.Format("AddSheet:%s", sSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }
		m_WorkRec.Add_Sheet(sSheetName, FALSE, TRUE);
		return;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////
		
	LPDISPATCH lpDisp;

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
  oSheets.AttachDispatch(lpDisp);

	lpDisp = oSheets.Add(vOpt,vOpt,COleVariant((short)1),vOpt);//�������
  oSheet.AttachDispatch(lpDisp);
	oSheet.SetName(sSheetName);
}

//Sheet�� �� �ڿ� ����
void CMSExcel::AddSheet2(CString sSheetName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;  strTemp.Format("AddSheet2:%s", sSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }
		m_WorkRec.Add_Sheet(sSheetName, FALSE, FALSE);
		return;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

	AddSheet(sSheetName);

	long SheetSu = oSheets.GetCount();
	LPDISPATCH lpDisp = oSheets.GetItem(COleVariant((long)SheetSu));
	oSheet.AttachDispatch(lpDisp);
	CString sLastSheet = oSheet.GetName();

	MoveSheet(sLastSheet, sSheetName);
}

void CMSExcel::DeleteSheet(CString sSheetName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;  strTemp.Format("DeleteSheet:%s", sSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }
		m_WorkRec.Del_Sheet(sSheetName);
		return;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

	LPDISPATCH lpDisp;

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
	oSheets.AttachDispatch(lpDisp);

	lpDisp = oSheets.GetItem(COleVariant(sSheetName));
	ASSERT(lpDisp);
	oSheet.AttachDispatch(lpDisp);
	oSheet.Delete();
}

//sSheet�� sSheetAfter�ڷ�
void CMSExcel::MoveSheet(CString sSheetAfter, CString sSheetName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;  strTemp.Format("MoveSheet:%s,%s", sSheetAfter, sSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }
		m_WorkRec.MoveSheet(sSheetAfter, sSheetName);
		return;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////
	
	SetActiveSheet(sSheetName);

	LPDISPATCH lpDisp;
	
	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
  oSheets.AttachDispatch(lpDisp);

	long nSheetSu = oSheets.GetCount();
  short nIndex = 0;
	for(short i=1; i<=nSheetSu; i++)
	{
		lpDisp = oSheets.GetItem(COleVariant((short)i));
		ASSERT(lpDisp);
		oTmpSheet.AttachDispatch(lpDisp);
		CString cs = oTmpSheet.GetName();
		if(cs==sSheetAfter)
    {
      nIndex = i;
      break;
    }
	}

	VARIANT Var;
	Var.vt = VT_DISPATCH;
	Var.pdispVal = lpDisp;
	oSheet.Move(vOpt,Var);

	lpDisp = oSheets.GetItem(COleVariant(nIndex));
	oSheet.AttachDispatch(lpDisp);
	oSheet.SetName(sSheetName);
}

//sSheet�� sSheetAfter�ڷ�
void CMSExcel::CopySheet(CString sSheetAfter, CString sSheetName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;  strTemp.Format("CopySheet:%s,%s", sSheetAfter, sSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }
		m_WorkRec.CopySheet(sSheetAfter, sSheetName);
		return;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

	LPDISPATCH lpDisp;
	
	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
  oSheets.AttachDispatch(lpDisp);

	long nSheetSu = oSheets.GetCount();
  short nIndex = 0;
	for(short i=1; i<=nSheetSu; i++)
	{
		lpDisp = oSheets.GetItem(COleVariant((short)i));
		ASSERT(lpDisp);
		oTmpSheet.AttachDispatch(lpDisp);
		CString cs = oTmpSheet.GetName();
		if(cs==sSheetAfter)       
    {
      nIndex = i;
      break;
    }
	}

	VARIANT Var;
	Var.vt = VT_DISPATCH;
	Var.pdispVal = lpDisp;
	oSheet.Copy(vOpt,Var);

	short j = nIndex+1;
	lpDisp = oSheets.GetItem(COleVariant((short)j));
	oSheet.AttachDispatch(lpDisp);
	oSheet.SetName(sSheetName);
}

void CMSExcel::SetVisible(BOOL bVis)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;  strTemp.Format("SetVisible:%s", (bVis ? "TRUE" : "FALSE"));  m_WorkRec.Add_WorkHistory(strTemp); }
		if(!m_bRecExcelRun) return;
		// CMSExcel�� �۾��� �����Ŵ
	}
	//////////////////////////////////

	oApp.SetVisible(bVis);
}

void CMSExcel::SetActiveBook(CString sBookName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;  strTemp.Format("SetActiveBook:%s", sBookName);  m_WorkRec.Add_WorkHistory(strTemp); }
		m_WorkRec.Set_Book(sBookName);		
		if(!m_bRecExcelRun) return;
		// CMSExcel�� �۾��� �����Ŵ
	}
	//////////////////////////////////

	LPDISPATCH lpDisp;

	lpDisp = oBooks.GetItem(COleVariant(sBookName));
	ASSERT(lpDisp);
  oBook.AttachDispatch(lpDisp);
}

void CMSExcel::SetActiveSheet(CString sSheetName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;  strTemp.Format("SetActiveSheet:%s", sSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }
		m_WorkRec.Set_Sheet(sSheetName);		
		return;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

	
	LPDISPATCH lpDisp;

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
	oSheets.AttachDispatch(lpDisp);

	lpDisp = oSheets.GetItem(COleVariant(sSheetName));
	ASSERT(lpDisp);
  oSheet.AttachDispatch(lpDisp);
}

void CMSExcel::SetSheetName(CString sSheetNameOld, CString sSheetNameNew)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;  strTemp.Format("SetSheetName:%s", sSheetNameOld, sSheetNameNew);  m_WorkRec.Add_WorkHistory(strTemp); }
		m_WorkRec.SetSheetName(sSheetNameOld, sSheetNameNew);		
		return;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

	LPDISPATCH lpDisp;

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
  oSheets.AttachDispatch(lpDisp);

	lpDisp = oSheets.GetItem(COleVariant(sSheetNameOld));
	ASSERT(lpDisp);
  oSheet.AttachDispatch(lpDisp);
	oSheet.SetName(sSheetNameNew);
}

void CMSExcel::GetSheetsName(CStringArray& aSheets)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { m_WorkRec.Add_WorkHistory("GetSheetsName"); }
		m_WorkRec.GetSheetsName(aSheets);		
		return;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

  aSheets.RemoveAll();

	LPDISPATCH lpDisp;

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
  oSheets.AttachDispatch(lpDisp);

	long count = oSheets.GetCount();
	for(short i=1; i<=count; i++)
	{
		lpDisp = oSheets.GetItem(COleVariant((short)i));
		ASSERT(lpDisp);
		oTmpSheet.AttachDispatch(lpDisp);
    aSheets.Add(oTmpSheet.GetName());
	}
}

CString CMSExcel::GetSheetName(short idx)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;  strTemp.Format("GetSheetName:%d", idx);  m_WorkRec.Add_WorkHistory(strTemp); }
		CStringArray aSheets;
		m_WorkRec.GetSheetsName(aSheets);
		if(aSheets.GetSize() <= idx) return "";		
		return aSheets.GetAt(idx);// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

  LPDISPATCH lpDisp;
  lpDisp = oBook.GetSheets();
  ASSERT(lpDisp);
  oSheets.AttachDispatch(lpDisp);

	oTmpSheet = oSheets.GetItem(COleVariant((short)(idx+1)));

	return oTmpSheet.GetName();
}

void CMSExcel::SetHideSheet(CString sSheetName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;  strTemp.Format("SetHideSheet:%s", sSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }		
		return;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////
	LPDISPATCH lpDisp;
	lpDisp = oSheets.GetItem(COleVariant(sSheetName));
	ASSERT(lpDisp);
	oSheet.AttachDispatch(lpDisp);
	oSheet.SetVisible(xlSheetHidden);
}

CString CMSExcel::GetBookName()
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { m_WorkRec.Add_WorkHistory("GetBookName"); }		
		return m_WorkRec.GetBookName();// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	CString sName = oBook.GetName();
	return sName;
}

void CMSExcel::SetValue(CString sCell, CString sVal)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetValue:[%s]%s", sCell, sVal);  m_WorkRec.Add_WorkHistory(strTemp); }
		else if(m_nRecType == 2) { short nRow, nCol;  GetCellID(sCell, nRow, nCol);                    m_WorkRec.Add_SheetItem(nRow, nCol, sVal); }
		return;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell),vOpt);
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	oRange.SetValue(COleVariant(sVal));
}

void CMSExcel::SetValue(CString sCell, double dVal)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetValue:[%s]%g", sCell, dVal);  m_WorkRec.Add_WorkHistory(strTemp); }
		else if(m_nRecType == 2) { short nRow, nCol;  GetCellID(sCell, nRow, nCol);                    m_WorkRec.Add_SheetItem(nRow, nCol, dVal); }
		return;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell),vOpt);
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	oRange.SetValue(COleVariant((double) dVal));
}

void CMSExcel::SetValue(short Row, short Col, CString sVal)
{
  CString sCell = GetCell(Row, Col);
  SetValue(sCell, sVal);
}

void CMSExcel::SetValue(short Row, short Col, double dVal)
{
  CString sCell = GetCell(Row, Col);
  SetValue(sCell, dVal);
}

void CMSExcel::SetValue_TextPass(CString sCell, CString sVal)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		return;// ������� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp;  
	Range oRange;
	lpDisp = oSheet.GetRange(COleVariant(sCell),vOpt);
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	oRange.SetValue(COleVariant(sVal));
}

void CMSExcel::SetValue_TextPass(CString sCell, double dVal)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		return;// ������� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp;
	Range oRange;
	lpDisp = oSheet.GetRange(COleVariant(sCell),vOpt);
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	oRange.SetValue(COleVariant((double) dVal));
}

void CMSExcel::SetValue_TextPass(short Row, short Col, CString sVal)
{
  CString sCell = GetCell(Row, Col);
  SetValue_TextPass(sCell, sVal);
}

void CMSExcel::SetValue_TextPass(short Row, short Col, double dVal)
{
  CString sCell = GetCell(Row, Col);
  SetValue_TextPass(sCell, dVal);
}

double CMSExcel::GetValue(CString sCell)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		CString strItem = "1";
		if(m_nRecType == 1)     
		{ CString strTemp;   strTemp.Format("GetValue:[%s]", sCell);  m_WorkRec.Add_WorkHistory(strTemp);  ASSERT(0); } // ������ ������δ� Regression Test�� �Ϻ��� ������ �����Ҽ� ���� ���� �ֽ��ϴ�.
		else if(m_nRecType == 2)
		{
			short nRow, nCol;  GetCellID(sCell, nRow, nCol); 		
			if(!m_WorkRec.GetValue(nRow, nCol, strItem)) 
				ASSERT(0);// ���� �Էµ� ���� �ƴϹǷ� �������� ���� �Ѱ��� �� �����ϴ�. Regression Test�� �Ϻ��� ������ ������ �� ���� ���� �ֽ��ϴ�.
		}		
		return atof(strItem);// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell),vOpt);
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	double dVal = (double)oRange.GetValue().dblVal;

	return dVal;
}

double CMSExcel::GetValue(short Row, short Col)
{
	CString sCell = GetCell(Row, Col);

	return GetValue(sCell);
}

CString CMSExcel::GetValueString(CString sCell)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format(_T("GetValue:[%s]"), sCell);  m_WorkRec.Add_WorkHistory(strTemp); }
		short nRow, nCol;  GetCellID(sCell, nRow, nCol); 
		CString strItem = "";
		if(!m_WorkRec.GetValue(nRow, nCol, strItem)) 
		{ 
      ASSERT(0); 
      return _T("1"); 
    }// �������� ���� �Ѱ��� �� �����ϴ�. Regression Test�� �Ϻ��� ������ �����Ҽ� ���� ���� �ֽ��ϴ�.
		return strItem;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell),vOpt);
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	CString sVal = (CString)oRange.GetValue().bstrVal;

	return sVal;
}

CString CMSExcel::GetValueString(short Row, short Col)
{
	CString sCell = GetCell(Row, Col);

	return GetValueString(sCell);
}

void CMSExcel::SetCellName(CString sCell, CString sCellName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetCellName:[%s]%s", sCell, sCellName);  m_WorkRec.Add_WorkHistory(strTemp); }		
		ASSERT(0); // sCellName�� �������� �ʾ����� �ش� Cell�� ��� ���� ���������� �����Ƿ�, Regression Test�� �Ϻ��� ������ �����Ҽ� ���� ���� �ֽ��ϴ�.
		return;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////
	
	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell),vOpt);
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	oRange.SetName(COleVariant(sCellName));
}

CString CMSExcel::GetCellName(CString sCell)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("GetCellName:[%s]", sCell);  m_WorkRec.Add_WorkHistory(strTemp); }		
		ASSERT(0); // SetCellName�� �������� �ʾ����Ƿ�, Regression Test�� �Ϻ��� ������ �����Ҽ� ���� ���� �ֽ��ϴ�.
		return sCell;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell),vOpt);
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	VARIANT var;
	var = oRange.GetName();
	CString sCellName = (CString)var.bstrVal;

	return sCellName;
}

void CMSExcel::SetColumnWidth(CString sCell1, CString sCell2, short newValue)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetColumnWidth:[%s-%s]%d", sCell1, sCell2, newValue);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	oRange.SetColumnWidth(COleVariant((short)newValue));
}

void CMSExcel::SetColumnWidth(CString sCell1, CString sCell2, double newValue)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetColumnWidth:[%s-%s]%g", sCell1, sCell2, newValue);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	oRange.SetColumnWidth(COleVariant((double)newValue));
}

void CMSExcel::SetColumnWidth(short Row1, short Col1, short Row2, short Col2, short newValue)
{
  CString sCell1 = GetCell(Row1, Col1);
	CString sCell2 = GetCell(Row2, Col2);

	SetColumnWidth(sCell1, sCell2, newValue);
}

void CMSExcel::SetColumnWidth(short Row1, short Col1, short Row2, short Col2, double newValue)
{
  CString sCell1 = GetCell(Row1, Col1);
	CString sCell2 = GetCell(Row2, Col2);

	SetColumnWidth(sCell1, sCell2, newValue);
}

void CMSExcel::SetRowHeight(CString sCell1, CString sCell2, short newValue)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetRowHeight:[%s-%s]%d", sCell1, sCell2, newValue);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	oRange.SetRowHeight(COleVariant((short)newValue));
}

// Add By GAY.('06.02.02). Set Row Height in Given Range.
void CMSExcel::SetRowHeight(short Row1, short Col1, short Row2, short Col2, short newValue)
{
  CString sCell1 = GetCell(Row1, Col1);
	CString sCell2 = GetCell(Row2, Col2);

	SetRowHeight(sCell1, sCell2, newValue);
}

// Add by GAY.('06.02.02). Set Row Height in Whole Sheet.
void CMSExcel::SetRowHeight(short newValue)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetRowHeight:[All]%d", newValue);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetCells();
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	oRange.SetRowHeight(COleVariant((short)newValue));
}

void CMSExcel::SetMergeCell(CString sCell1, CString sCell2)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetMergeCell:[%s-%s]", sCell1, sCell2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	VARIANT newValue = oRange.GetHeight();
	oRange.SetMergeCells(newValue);
}

void CMSExcel::SetMergeCell(short Row1, short Col1, short Row2, short Col2)
{
  CString sCell1 = GetCell(Row1, Col1);
	CString sCell2 = GetCell(Row2, Col2);

	SetMergeCell(sCell1, sCell2);
}

void CMSExcel::SetHorAlign(CString sCell1, CString sCell2, short Align)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetHorAlign:[%s-%s]%d", sCell1, sCell2, Align);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	oRange.SetHorizontalAlignment(COleVariant((short)Align));
}

void CMSExcel::SetVerAlign(CString sCell1, CString sCell2, short Align)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetVerAlign:[%s-%s]%d", sCell1, sCell2, Align);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	oRange.SetVerticalAlignment(COleVariant((short)Align));
}

void CMSExcel::SetHorAlign(short Row1, short Col1, short Row2, short Col2, short Align)
{
  CString sCell1 = GetCell(Row1, Col1);
	CString sCell2 = GetCell(Row2, Col2);

	SetHorAlign(sCell1, sCell2, Align);
}

void CMSExcel::SetVerAlign(short Row1, short Col1, short Row2, short Col2, short Align)
{
  CString sCell1 = GetCell(Row1, Col1);
	CString sCell2 = GetCell(Row2, Col2);

	SetVerAlign(sCell1, sCell2, Align);
}

void CMSExcel::SetFont(CString sCell1, CString sCell2, short Height, COLORREF Color, CString sType, BOOL bBold)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetFont:[%s-%s]%d", sCell1, sCell2, Height);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oFont = oRange.GetFont();
	oFont.SetSize(COleVariant((short)Height));
	oFont.SetColor(COleVariant((double)Color));
	oFont.SetName(COleVariant(sType));

	if(bBold)
		oFont.SetBold(vTrue);
	else
		oFont.SetBold(vFalse);
}

void CMSExcel::SetFont(CString sCell1, CString sCell2, short Height, CString sType)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetFont:[%s-%s]%d", sCell1, sCell2, Height);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////
	
	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oFont = oRange.GetFont();
	oFont.SetSize(COleVariant((short)Height));
//	font.SetColorIndex(COleVariant((long)Color));
	oFont.SetName(COleVariant(sType));
/*
	if(bBold)
		font.SetBold(vTrue);
	else
		font.SetBold(vFalse);
*/
}

void CMSExcel::SetFont(short Row1, short Col1, short Row2, short Col2, short Height, CString sType)
{
  CString sCell1 = GetCell(Row1, Col1);
	CString sCell2 = GetCell(Row2, Col2);
  
  SetFont(sCell1, sCell2, Height, sType);
}

void CMSExcel::SetFont(short Row1, short Col1, short Row2, short Col2, short Height, COLORREF Color, CString sType, BOOL bBold)
{
  CString sCell1 = GetCell(Row1, Col1);
	CString sCell2 = GetCell(Row2, Col2);

	SetFont(sCell1, sCell2, Height, Color, sType, bBold);
}

void CMSExcel::SetFontFace(CString sCell1, CString sCell2, CString sFontName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetFontFace:[%s-%s]%s", sCell1, sCell2, sFontName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////	

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oFont = oRange.GetFont();
	oFont.SetName(COleVariant(sFontName));
}

void CMSExcel::SetFontSize(CString sCell1, CString sCell2, short Height)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetFontSize:[%s-%s]%d", sCell1, sCell2, Height);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////
	
	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oFont = oRange.GetFont();
	oFont.SetSize(COleVariant((short)Height));  
}

void CMSExcel::SetFontBold(CString sCell1, CString sCell2, BOOL bBold)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetFontBold:[%s-%s]%s", sCell1, sCell2, (bBold ? "TRUE" : "FALSE"));  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////
	
	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oFont = oRange.GetFont();

	if(bBold)
		oFont.SetBold(vTrue);
	else
		oFont.SetBold(vFalse);
}

void CMSExcel::SetFontBold(short Row1, short Col1, short Row2, short Col2, BOOL bBold)
{
  CString sCell1 = GetCell(Row1, Col1);
  CString sCell2 = GetCell(Row2, Col2);

  SetFontBold(sCell1, sCell2, bBold);
}

void CMSExcel::SetFontUnderline(CString sCell1, CString sCell2, BOOL bUnder)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetFontUnderline:[%s-%s]%s", sCell1, sCell2, (bUnder ? "TRUE" : "FALSE"));  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

  LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
  ASSERT(lpDisp);
  oRange.AttachDispatch(lpDisp);
  
  oFont = oRange.GetFont();

  COleVariant OptTrue  = COleVariant((short)TRUE , VT_BOOL);
  COleVariant OptFalse = COleVariant((short)FALSE, VT_BOOL); 

  if(bUnder)
    oFont.SetUnderline(OptTrue);
  else
    oFont.SetUnderline(OptFalse);
}

void CMSExcel::SetFontUnderline(short Row1, short Col1, short Row2, short Col2, BOOL bUnder)
{
  CString sCell1 = GetCell(Row1, Col1);
  CString sCell2 = GetCell(Row2, Col2);
  
  SetFontUnderline(sCell1, sCell2, bUnder);
}

void CMSExcel::SetFontOutline(CString sCell1, CString sCell2, BOOL bOutLine)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetFontOutline:[%s-%s]%s", sCell1, sCell2, (bOutLine ? "TRUE" : "FALSE"));  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

  LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
  ASSERT(lpDisp);
  oRange.AttachDispatch(lpDisp);
  
  oFont = oRange.GetFont();
  
  COleVariant OptTrue  = COleVariant((short)TRUE , VT_BOOL);
  COleVariant OptFalse = COleVariant((short)FALSE, VT_BOOL);

  if(bOutLine)
    oFont.SetOutlineFont(OptTrue);
  else
    oFont.SetOutlineFont(OptFalse);
}

void CMSExcel::SetFontOutline(short Row1, short Col1, short Row2, short Col2, BOOL bOutLine)
{
  CString sCell1 = GetCell(Row1, Col1);
  CString sCell2 = GetCell(Row2, Col2);
  
  SetFontOutline(sCell1, sCell2, bOutLine);
}

void CMSExcel::SetFontStrikethrough(CString sCell1, CString sCell2, BOOL bStrikethrough)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetFontStrikethrough:[%s-%s]%s", sCell1, sCell2, (bStrikethrough ? "TRUE" : "FALSE"));  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

  LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
  ASSERT(lpDisp);
  oRange.AttachDispatch(lpDisp);
  
  oFont = oRange.GetFont();

  COleVariant OptTrue  = COleVariant((short)TRUE , VT_BOOL);
  COleVariant OptFalse = COleVariant((short)FALSE, VT_BOOL);
  
  if(bStrikethrough)
    oFont.SetStrikethrough(OptTrue);
  else
    oFont.SetStrikethrough(OptFalse);
}

void CMSExcel::SetFontStrikethrough(short Row1, short Col1, short Row2, short Col2, BOOL bStrikethrough)
{
  CString sCell1 = GetCell(Row1, Col1);
  CString sCell2 = GetCell(Row2, Col2);
  
  SetFontStrikethrough(sCell1, sCell2, bStrikethrough);
}

void CMSExcel::SetFontSubscript(CString sCell1, CString sCell2, BOOL bSubscript)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetFontSubscript:[%s-%s]%s", sCell1, sCell2, (bSubscript ? "TRUE" : "FALSE"));  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

  LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
  ASSERT(lpDisp);
  oRange.AttachDispatch(lpDisp);
  
  oFont = oRange.GetFont();
  
  if(bSubscript)
    oFont.SetSubscript(vTrue);
  else
    oFont.SetSubscript(vFalse);
}

void CMSExcel::SetFontSubscript(short Row1, short Col1, short Row2, short Col2, BOOL bSubscript)
{
  CString sCell1 = GetCell(Row1, Col1);
  CString sCell2 = GetCell(Row2, Col2);
  
  SetFontSubscript(sCell1, sCell2, bSubscript);
}

void CMSExcel::SetFontSuperscript(CString sCell1, CString sCell2, BOOL bSuperscript)
{	
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetFontSuperscript:[%s-%s]%s", sCell1, sCell2, (bSuperscript ? "TRUE" : "FALSE"));  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

  LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
  ASSERT(lpDisp);
  oRange.AttachDispatch(lpDisp);
  
  oFont = oRange.GetFont();
  
  if(bSuperscript)
    oFont.SetSuperscript(vTrue);
  else
    oFont.SetSuperscript(vFalse);
}

void CMSExcel::SetFontSuperscript(short Row1, short Col1, short Row2, short Col2, BOOL bSuperscript)
{
  CString sCell1 = GetCell(Row1, Col1);
  CString sCell2 = GetCell(Row2, Col2);
  
  SetFontSuperscript(sCell1, sCell2, bSuperscript);
}

void CMSExcel::SetValueSuperscript(CString sCell, CString sVal, int iStart, int iLen)        // Add by GAY.('10.10.28)
{
  // Text ��Ͻ� ///////////////////
  if(m_nRecType == 1 || m_nRecType == 2)
  {// Text ��Ϲ��
    if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetValueSuperScript:[%s-%s:%d-%d]", sCell, sVal, iStart, iLen);  m_WorkRec.Add_WorkHistory(strTemp); }
    return ;// CMSExcel�� �۾��� ���� ����
  } 
	//////////////////////////////////

  LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell),COleVariant(sCell));
  ASSERT(lpDisp);
  oRange.AttachDispatch(lpDisp);
  oRange.SetValue(COleVariant(sVal));

  lpDisp = oRange.GetCharacters(COleVariant((short)iStart), COleVariant((short)iLen));
  ASSERT(lpDisp);
  oCharacters.AttachDispatch(lpDisp);

  lpDisp = oCharacters.GetFont();
  ASSERT(lpDisp);
  oFont.AttachDispatch(lpDisp);
  oFont.SetSuperscript(vTrue);
}

void CMSExcel::SetValueSuperscript(short Row, short Col, CString sVal, int iStart, int iLen) // Add by GAY.('10.10.28)
{
  CString sCell = GetCell(Row, Col);

  SetValueSuperscript(sCell, sVal, iStart, iLen);
}

void CMSExcel::SetValueSubscript(CString sCell, CString sVal, int iStart, int iLen)          // Add by GAY.('10.10.28)
{
  // Text ��Ͻ� ///////////////////
  if(m_nRecType == 1 || m_nRecType == 2)
  {// Text ��Ϲ��
    if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetValueSubscript:[%s-%s:%d-%d]", sCell, sVal, iStart, iLen);  m_WorkRec.Add_WorkHistory(strTemp); }
    return ;// CMSExcel�� �۾��� ���� ����
  } 
  //////////////////////////////////
  
  LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell),COleVariant(sCell));
  ASSERT(lpDisp);
  oRange.AttachDispatch(lpDisp);
  oRange.SetValue(COleVariant(sVal));
  
  lpDisp = oRange.GetCharacters(COleVariant((short)iStart), COleVariant((short)iLen));
  ASSERT(lpDisp);
  oCharacters.AttachDispatch(lpDisp);
  
  lpDisp = oCharacters.GetFont();
  ASSERT(lpDisp);
  oFont.AttachDispatch(lpDisp);
  oFont.SetSubscript(vTrue);
}

void CMSExcel::SetValueSubscript(short Row, short Col, CString sVal, int iStart, int iLen)   // Add by GAY.('10.10.28)
{
  CString sCell = GetCell(Row, Col);
  
  SetValueSubscript(sCell, sVal, iStart, iLen);
}

void CMSExcel::SetTextColor(CString sCell1, CString sCell2, COLORREF Color)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetTextColor:[%s-%s]", sCell1, sCell2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oFont = oRange.GetFont();
	oFont.SetColor(COleVariant((double)Color));
}

void CMSExcel::SetTextColor(short Row1, short Col1, short Row2, short Col2, COLORREF color)
{
  CString sCell1 = GetCell(Row1, Col1);
  CString sCell2 = GetCell(Row2, Col2);
  SetTextColor(sCell1, sCell2, color);
}

void CMSExcel::SetBackColor(CString sCell1, CString sCell2, COLORREF Color)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetBackColor:[%s-%s]", sCell1, sCell2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oInterior = oRange.GetInterior();
	oInterior.SetColor(COleVariant((double)Color));
}

void CMSExcel::SetBackColor(short Row1, short Col1, short Row2, short Col2, COLORREF color)
{
  CString sCell1 = GetCell(Row1, Col1);
  CString sCell2 = GetCell(Row2, Col2);
  SetBackColor(sCell1, sCell2, color);
}

void CMSExcel::SetBorder(CString sCell1, CString sCell2, short LineStyle, short Thick)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetBorder:[%s-%s]", sCell1, sCell2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oBorders = oRange.GetBorders();
	oBorders.SetLineStyle(COleVariant((short)LineStyle));
	oBorders.SetWeight(COleVariant((short)Thick));
}

void CMSExcel::SetBorder(short Row1, short Col1, short Row2, short Col2, short LineStyle, short Thick)
{
  CString sCell1 = GetCell(Row1, Col1);
	CString sCell2 = GetCell(Row2, Col2);

	SetBorder(sCell1, sCell2, LineStyle, Thick);
}

void CMSExcel::SetNumberFormat(CString sCell1, CString sCell2, CString sFormat)
{	
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetNumberFormat:[%s-%s]", sCell1, sCell2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	oRange.SetNumberFormat(COleVariant(sFormat));
}

void CMSExcel::SetNumberFormat(short Row1, short Col1, short Row2, short Col2, CString sFormat)
{
  CString sCell1 = GetCell(Row1, Col1);
	CString sCell2 = GetCell(Row2, Col2);

	SetNumberFormat(sCell1, sCell2, sFormat);
}

//Direction  1: ��缿�� ����, 2: ��缿�� ����, 3: ��缿�� top, 4: ��缿�� bottom, 5: �밢��(��), 6: �밢��(��)
//           7: ���ÿ����� �� ����, 8: ���ÿ����� top, 9: ���ÿ����� bottom, 10: ���ÿ����� �� ����, 11: ���ÿ����� ������ ����(����), 12: ���ÿ����� ������ ����(����)
void CMSExcel::CellLine(CString sCell1, CString sCell2, short Direction, short LineStyle, short Thick, short LineColor)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("CellLine:[%s-%s]", sCell1, sCell2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	lpDisp = oRange.GetBorders();
	oBorders.AttachDispatch(lpDisp);

	lpDisp = oBorders.GetItem(Direction);
	oBorder.AttachDispatch(lpDisp);
	oBorder.SetLineStyle(COleVariant((short)LineStyle));
	oBorder.SetWeight(COleVariant((short)Thick));
	oBorder.SetColorIndex(COleVariant((short)LineColor));
}

void CMSExcel::CellLine(short Row1, short Col1, short Row2, short Col2, short Direction, short LineStyle, short Thick, short LineColor)
{
  CString sCell1 = GetCell(Row1, Col1);
	CString sCell2 = GetCell(Row2, Col2);

	CellLine(sCell1, sCell2, Direction, LineStyle, Thick, LineColor);
}

void CMSExcel::CellOutLine(CString sCell1, CString sCell2, short LineStyle, short Thick, short LineColor)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("CellOutLine:[%s-%s]", sCell1, sCell2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oRange.BorderAround(COleVariant((short)LineStyle),Thick,LineColor,COleVariant((short)1));
}

void CMSExcel::CellOutLine(short Row1, short Col1, short Row2, short Col2, short LineStyle, short Thick, short LineColor)
{
  CString sCell1 = GetCell(Row1, Col1);
	CString sCell2 = GetCell(Row2, Col2);

	CellOutLine(sCell1, sCell2, LineStyle, Thick, LineColor);
}

void CMSExcel::LineTo(float X1, float Y1, float X2, float Y2)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("LineTo:(%g,%g)-(%g,%g)", X1, Y1, X2, Y2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp;	
	lpDisp = oSheet.GetShapes();
	ASSERT(lpDisp);
	oShapes.AttachDispatch(lpDisp);

	Line line;
	line = oShapes.AddLine(X1,Y1,X2,Y2);
}

//copy:sCell1,sCell2   paste:sCell3,sCell4
void CMSExcel::Copy(CString sCell1, CString sCell2, CString sCell3, CString sCell4)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("Copy:[%s,%s]-[%s,%s]", sCell1, sCell2, sCell3, sCell4);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp, lpPaste;	
	lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oRange.Copy(vOpt);

	lpPaste = oSheet.GetRange(COleVariant(sCell3),COleVariant(sCell4));
	ASSERT(lpPaste);
	oRange.AttachDispatch(lpPaste);

    VARIANT Var;
	Var.vt = VT_DISPATCH;
	Var.pdispVal = lpPaste; 

	oSheet.Paste(Var,vFalse);
}

void CMSExcel::CopyRow(CString sCell1, CString sCell2)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("CopyRow:[%s-%s]", sCell1, sCell2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////
	
	CString sOld1 = sCell1;
	CString sOld2 = sCell2;

	sCell1.Delete(0);
	sCell2.Delete(0);

	int nCell1 = atoi(sCell1);
	int nCell2 = atoi(sCell2);
	int nSub = nCell2 - nCell1;

	CString sCell3, sCell4;

	//�Ϲ�ȭ�� ������ ������ ��.
	sOld2.Format("AP%d", nCell2);
	sCell3.Format("H%d", nCell2+1);
	sCell4.Format("AP%d", nCell2+nSub+1);

	InsertCell(sCell3, sCell4);
	Copy(sOld1, sOld2, sCell3, sCell4);
}

void CMSExcel::CopyPicture(short Row, short Col, CString sBookName, CString sSheetName, CString sPicName)
{
	CString sCell = GetCell(Row, Col);

	CopyPicture(sCell, sBookName, sSheetName, sPicName);
}

void CMSExcel::CopyPicture(CString sCell, CString sBookName, CString sSheetName, CString sPicName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("CopyPicture:[%s]%s-%s-%s", sCell, sBookName, sSheetName, sPicName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	CString OldBookName = oBook.GetName();
	CString OldSheetName = oSheet.GetName();

	LPDISPATCH lpDisp;

	lpDisp = oBooks.GetItem(COleVariant(sBookName));
	ASSERT(lpDisp);
    oBook.AttachDispatch(lpDisp);

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
    oSheets.AttachDispatch(lpDisp);

	lpDisp = oSheets.GetItem(COleVariant(sSheetName));
	ASSERT(lpDisp);
    oSheet.AttachDispatch(lpDisp);

	VARIANT vRange;
	vRange = oSheet.Evaluate(COleVariant(sPicName));
	lpDisp = vRange.pdispVal;
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

//	oRange.AttachDispatch(lpDisp);
	oRange.CopyPicture(1,1);

	lpDisp = oBooks.GetItem(COleVariant(OldBookName));
	ASSERT(lpDisp);
    oBook.AttachDispatch(lpDisp);

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
    oSheets.AttachDispatch(lpDisp);

	lpDisp = oSheets.GetItem(COleVariant(OldSheetName));
	ASSERT(lpDisp);
    oSheet.AttachDispatch(lpDisp);

	lpDisp = oSheet.GetRange(COleVariant(sCell),COleVariant(sCell));

    VARIANT Var;
	Var.vt = VT_DISPATCH;
	Var.pdispVal = lpDisp; 

	oSheet.Paste(Var,vFalse);
//  lpDisp->Release();
}

void CMSExcel::CopyRange(short Row, short Col, CString sBookName, CString sSheetName, CString sRangeName)
{
	CString sCell = GetCell(Row, Col);

	CopyRange(sCell, sBookName, sSheetName, sRangeName);
}

void CMSExcel::CopyRange(CString sCell, CString sBookName, CString sSheetName, CString sRangeName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("CopyRange:[%s]%s-%s-%s", sCell, sBookName, sSheetName, sRangeName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// Return ���� �����Ƿ� CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	CString OldBookName = oBook.GetName();
	CString OldSheetName = oSheet.GetName();

	LPDISPATCH lpDisp;

	lpDisp = oBooks.GetItem(COleVariant(sBookName));
	ASSERT(lpDisp);
  oBook.AttachDispatch(lpDisp);

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
  oSheets.AttachDispatch(lpDisp);

	oSheet = oSheets.GetItem(COleVariant(sSheetName));
	
	VARIANT vRange;
	vRange = oSheet.Evaluate(COleVariant(sRangeName));
	lpDisp = vRange.pdispVal;
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

//	oRange.AttachDispatch(lpDisp);  
  oRange.Copy(vOpt);

	lpDisp = oBooks.GetItem(COleVariant(OldBookName));
	ASSERT(lpDisp);
    oBook.AttachDispatch(lpDisp);

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
    oSheets.AttachDispatch(lpDisp);

	lpDisp = oSheets.GetItem(COleVariant(OldSheetName));
	ASSERT(lpDisp);
    oSheet.AttachDispatch(lpDisp);

	lpDisp = oSheet.GetRange(COleVariant(sCell),COleVariant(sCell));

    VARIANT Var;
	Var.vt = VT_DISPATCH;
	Var.pdispVal = lpDisp; 

	oSheet.Paste(Var,vFalse);
//  lpDisp->Release();
}

// Add by GAY.('06.02.01).
// ���� Active�� Sheet�� sCell�� sBookName + sSheetName + sRangeName�� Range�� �����Ͽ� �ٿ��ִ´�.
// [param] �ٿ����� ��ġ�� Cell �̸�.
// [param] sBookName  : �������� Range�� ��ġ�� WorkBook�� �̸�.
// [param] sSheetName : �������� Range�� ��ġ�� WorkSheet�� �̸�.
// [param] sRangeName : �������� Range �̸�.
// [param] rowCnt : Range�� �����ϴ� ���.
// [param] colCnt : Range�� �����ϴ� ����.
void CMSExcel::CopyRange(CString sCell, CString sBookName, CString sSheetName, CString sRangeName, int& rowCnt, int& colCnt)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("CopyRange:[%s]%s-%s-%s", sCell, sBookName, sSheetName, sRangeName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		if(!m_bRecExcelRun) { rowCnt = colCnt = m_nRecDefaultRangeCount;   return; }
		// Return���� �ʿ��ϹǷ� CMSExcel�� �۾��� �����Ŵ
		CString OldBookName  = m_WorkRec.GetBookName();
		CString OldSheetName = m_WorkRec.GetSheetName();

		LPDISPATCH lpDisp;

		lpDisp = oBooks.GetItem(COleVariant(sBookName));
		ASSERT(lpDisp);
		oBook.AttachDispatch(lpDisp);

		lpDisp = oBook.GetSheets();
		ASSERT(lpDisp);
		oSheets.AttachDispatch(lpDisp);

		lpDisp = oSheets.GetItem(COleVariant(sSheetName));
		ASSERT(lpDisp);
		oSheet.AttachDispatch(lpDisp);

		VARIANT vRange;
		vRange = oSheet.Evaluate(COleVariant(sRangeName));
		lpDisp = vRange.pdispVal;
		ASSERT(lpDisp);
		Range oRange(lpDisp);

		rowCnt = GetPropertyCount(oRange.GetRows());
		colCnt = GetPropertyCount(oRange.GetColumns());   

		m_WorkRec.Set_Book(OldBookName);
		m_WorkRec.Set_Sheet(OldSheetName);

		return;
	} 
	//////////////////////////////////
	
	CString OldBookName  = oBook.GetName();
	CString OldSheetName = oSheet.GetName();

	LPDISPATCH lpDisp;

	lpDisp = oBooks.GetItem(COleVariant(sBookName));
	ASSERT(lpDisp);
  oBook.AttachDispatch(lpDisp);

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
  oSheets.AttachDispatch(lpDisp);

	lpDisp = oSheets.GetItem(COleVariant(sSheetName));
	ASSERT(lpDisp);
  oSheet.AttachDispatch(lpDisp);

	VARIANT vRange;
	vRange = oSheet.Evaluate(COleVariant(sRangeName));
	lpDisp = vRange.pdispVal;
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

  oRange.Copy(vOpt);

	lpDisp = oBooks.GetItem(COleVariant(OldBookName));
	ASSERT(lpDisp);
  oBook.AttachDispatch(lpDisp);

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
  oSheets.AttachDispatch(lpDisp);

	lpDisp = oSheets.GetItem(COleVariant(OldSheetName));
	ASSERT(lpDisp);
  oSheet.AttachDispatch(lpDisp);

	lpDisp = oSheet.GetRange(COleVariant(sCell),COleVariant(sCell));

  VARIANT Var;
	Var.vt = VT_DISPATCH;
	Var.pdispVal = lpDisp; 

	oSheet.Paste(Var,vFalse);

  rowCnt = GetPropertyCount(oRange.GetRows());
  colCnt = GetPropertyCount(oRange.GetColumns());   
}

// Add by GAY.('06.02.01).
// ���� Active�� Sheet�� sCell�� sBookName + sSheetName + sRangeName�� Range�� �����Ͽ� �ٿ��ִ´�.
// [param] Row : �ٿ����� ��ġ�� Row index
// [param] Col : �ٿ����� ��ġ�� Col index
// [param] sBookName  : �������� Range�� ��ġ�� WorkBook�� �̸�.
// [param] sSheetName : �������� Range�� ��ġ�� WorkSheet�� �̸�.
// [param] sRangeName : �������� Range �̸�.
// [param] rowCnt : Range�� �����ϴ� ���.
// [param] colCnt : Range�� �����ϴ� ����.
void CMSExcel::CopyRange(short Row, short Col, CString sBookName, CString sSheetName, CString sRangeName, int& rowCnt, int& colCnt)
{
  CString strCell = GetCell(Row, Col);
  CopyRange(strCell, sBookName, sSheetName, sRangeName, rowCnt, colCnt);
}

//Left:X, Top:Y ������ǥ,  Width, Heith: ���� ����
//File ����: bmp, jpg, emf, wmf ��
void CMSExcel::AddPicture(CString sFilename, float Left, float Top, float Width, float Height)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("AddPicture:(%g,%g)-(%g,%g)%s", Left, Top, Width, Height, sFilename);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp;
	
	lpDisp = oSheet.GetShapes();
	ASSERT(lpDisp);
	oShapes.AttachDispatch(lpDisp);

	lpDisp = oShapes.AddPicture(sFilename, FALSE, TRUE, Left, Top, Width, Height);
	//lpDisp->Release();
}

void CMSExcel::AddPicture(short Row, short Col, float Width, float Height, CString sFilename)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("AddPicture:[%d,%d]-(%g,%g)%s", Row, Col, Width, Height, sFilename);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp;

	CString sCell;
	sCell.Format("A%d", Row);
	
	lpDisp = oSheet.GetRange(COleVariant(sCell),COleVariant(sCell));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	float Wi = (float)oRange.GetWidth().dblVal;
	float He = (float)oRange.GetHeight().dblVal;
	
	lpDisp = oSheet.GetShapes();	
	ASSERT(lpDisp);
	oShapes.AttachDispatch(lpDisp);

	float Left = Wi * Col;
	float Top = He * Row;

	lpDisp = oShapes.AddPicture(sFilename, FALSE, TRUE, Left, Top, Width, Height);
	//lpDisp->Release();
}

void CMSExcel::AddPicture_Count(short Row, short Col, short RowCount, short ColCount, CString sFilename)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("AddPicture_Count:[%d,%d]-[%d,%d]%s", Row, Col, RowCount, ColCount, sFilename);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp;

	CString sCell;
	sCell.Format("A%d", Row);
	
	lpDisp = oSheet.GetRange(COleVariant(sCell),COleVariant(sCell));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	float Wi = (float)oRange.GetWidth().dblVal;
	float He = (float)oRange.GetHeight().dblVal;	
	
	lpDisp = oSheet.GetShapes();	
	ASSERT(lpDisp);
	oShapes.AttachDispatch(lpDisp);

	float Left = Wi * Col;
	float Top = He * Row;
	float Width = Wi * ColCount;
	float Height = He * RowCount;

	lpDisp = oShapes.AddPicture(sFilename, FALSE, TRUE, Left, Top, Width, Height);
  /*
  // Modify by GAY. MNET:XXXX. ('08.03.06). ���ԵǴ� �׸��� �Ӽ��� ũ��>����>���� ���� ���� ���� Check Off �ϵ��� ��.
  Picture oPicture;
  oPicture.AttachDispatch(lpDisp);
  lpDisp = oPicture.GetShapeRange();

  ShapeRange oShapeRange;
  oShapeRange.AttachDispatch(lpDisp);
  oShapeRange.SetLockAspectRatio(0);  // Set Check Off. If Set Check On, change (0)->(-1).
  */
	//lpDisp->Release();
}

/*iOpt - 1:���������� �̵� 2:�Ʒ��� �̵� 3:�� ���� 4:�� ����*/
void CMSExcel::InsertCell(CString sCell1, CString sCell2, short iOpt)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("InsertCell:[%s-%s]", sCell1, sCell2);  m_WorkRec.Add_WorkHistory(strTemp); }		
		else if(m_nRecType == 2) 
		{ 
			short Row1,Col1,Row2,Col2;   
			GetCellID(sCell1,Row1,Col1);   
			GetCellID(sCell2,Row2,Col2);    
			m_WorkRec.InsertCell(Row1, Col1, Row2, Col2, iOpt);
		}
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oRange.Insert(COleVariant((short)iOpt));
}

/*iOpt - 1:�������� �̵� 2:�����̵� 3:�� ���� 4:�� ����*/
void CMSExcel::DeletCell(CString sCell1, CString sCell2, short iOpt)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("DeletCell:[%s-%s]", sCell1, sCell2);  m_WorkRec.Add_WorkHistory(strTemp); }		
		else if(m_nRecType == 2) 
		{ 
			short Row1,Col1,Row2,Col2;   
			GetCellID(sCell1,Row1,Col1);   
			GetCellID(sCell2,Row2,Col2);    
			m_WorkRec.DeletCell(Row1, Col1, Row2, Col2, iOpt);
		}
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oRange.Delete(COleVariant((short)iOpt));
}

void CMSExcel::Clear(CString sCell1, CString sCell2)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("Clear:[%s-%s]", sCell1, sCell2);  m_WorkRec.Add_WorkHistory(strTemp); }		
		else if(m_nRecType == 2) 
		{ 
			short Row1,Col1,Row2,Col2;   
			GetCellID(sCell1,Row1,Col1);   
			GetCellID(sCell2,Row2,Col2);    
			m_WorkRec.Clear(Row1, Col1, Row2, Col2);
		}
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oRange.Clear();
}

void CMSExcel::DeleteName(const CString& strName)
{
  LPDISPATCH lpDisp = oBook.GetNames();
  ASSERT(lpDisp);
  oNames.AttachDispatch(lpDisp);

  lpDisp = oNames.Item(COleVariant(strName), COleVariant(strName), COleVariant(strName));
  ASSERT(lpDisp);
  oName.AttachDispatch(lpDisp);

  oName.Delete();  
}

CString CMSExcel::GetCell(short Row, short Col)
{
	CString sCol, sRow;

	sRow.Format("%d", Row+1);

	if(Col < 26)
	{
		sCol.Format("%c", (char)('A'+Col));
	}
	else if(Col < 255)
	{
		long first, second;
		first = Col / 26 - 1;
		second = Col % 26;
		sCol.Format("%c%c", (char)('A'+first), (char)('A'+second));
	}

	CString sCell = sCol + sRow;

	return sCell;
}

void CMSExcel::GetCellID(CString strCell, short& Row, short& Col)
{
	Row = Col = 0;
	int nSize = strCell.GetLength();
	if(nSize < 2) return;
	int nFirst  = strCell.GetAt(0) - 'A';
	int nSecond = strCell.GetAt(1) - 'A';
	if(nFirst < 0 || nFirst > 26) return;
	CString strRow = "";
	if(nSecond < 0 || nSecond > 26)
	{
		Col = nFirst;
		strRow = strCell.Right(nSize-1);
	}
	else 
	{
		Col = (nFirst+1)*26 + nSecond;
		strRow = strCell.Right(nSize-2);
	}
	Row =atoi(strRow);
}

void CMSExcel::GetCellIDByName(const CString& strCellName, short& Row, short& Col)  // �̸������ڿ� ���ǵ� �̸����� Row, Col ��ȣ ����
{
  Row = Col = 0;

  LPDISPATCH lpDisp;
  lpDisp = oBook.GetNames();
  ASSERT(lpDisp);
  oNames.AttachDispatch(lpDisp);

  lpDisp = oNames.Item(COleVariant(strCellName), COleVariant(strCellName), COleVariant(strCellName));
  ASSERT(lpDisp);
  oName.AttachDispatch(lpDisp);

  lpDisp = oName.GetRefersToRange();
  ASSERT(lpDisp);
  oRange.AttachDispatch(lpDisp);

  Row = oRange.GetRow()-1;
  Col = oRange.GetColumn()-1;
}

CString CMSExcel::GetCellOrgExp(short Row, short Col)
{
	CString sCol, sRow;

	sRow.Format("%d", Row+1);

	if(Col < 26)
	{
		sCol.Format("%c", (char)('A'+Col));
	}
	else if(Col < 255)
	{
		long first, second;
		first = Col / 26 - 1;
		second = Col % 26;
		sCol.Format("%c%c", (char)('A'+first), (char)('A'+second));
	}

	CString sCell = "$" + sCol + "$" + sRow;

	return sCell;
}

void CMSExcel::GetCellSize(short Row1, short Col1, short Row2, short Col2, double& dWidth, double& dHeight, double& dLeft, double& dTop)//rsh
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("GetCellSize:[%d,%d-%d,%d]", Row1, Col1, Row2, Col2);  m_WorkRec.Add_WorkHistory(strTemp); }		
		// Text ��Ϲ�����δ� ��Ȯ�� ���� �Ѱ� �ټ� �����ϴ�.
		dLeft   =  2.0*Col1;
		dTop    = 13.5*Row1; 
		dWidth  =  2.0*(abs(Row1-Row2));
		dHeight = 13.5*(abs(Col1-Col2));
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////


	CString sCell1 = GetCell(Row1, Col1);
	CString sCell2 = GetCell(Row2, Col2);

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	dWidth = oRange.GetWidth().dblVal;
	dHeight = oRange.GetHeight().dblVal;
	dLeft = oRange.GetLeft().dblVal;
	dTop = oRange.GetTop().dblVal;
}

void CMSExcel::SetCellInTextFormat(CString sCell1, CString sCell2) // rsh
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetCellInTextFormat:[%s-%s]", sCell1, sCell2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oRange.SetNumberFormatLocal(COleVariant("@")); 
}

void CMSExcel::SetCellInTextFormat(short iRow1, short iCol1, short iRow2, short iCol2) // rsh
{
	CString sCell1 = GetCell(iRow1, iCol1);
	CString sCell2 = GetCell(iRow2, iCol2);
	SetCellInTextFormat(sCell1, sCell2);
}

void CMSExcel::SetColumnInTextFormat(short iCol1, short iCol2) // rsh
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetColumnInTextFormat:[%d-%d]", iCol1, iCol2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	CString sCell1 = GetCell(0, iCol1);
	CString sCell2 = GetCell((short)65535, iCol2);

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oRange.SetNumberFormatLocal(COleVariant("@")); 
}

void CMSExcel::SetCellInNumber3DotFormat(short iRow1, short iCol1, short iRow2, short iCol2) // rsh
{
	CString sCell1 = GetCell(iRow1, iCol1);
	CString sCell2 = GetCell(iRow2, iCol2);
	SetCellInNumber3DotFormat(sCell1, sCell2);
}

void CMSExcel::SetColumnInNumber3DotFormat(short iCol1, short iCol2) // rsh
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetColumnInNumber3DotFormat:[%d-%d]", iCol1, iCol2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	CString sCell1 = GetCell(0, iCol1);
	CString sCell2 = GetCell((short)65535, iCol2);

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oRange.SetNumberFormatLocal(COleVariant("0.000_ ")); 
}

void CMSExcel::SetCellInNumber3DotFormat(CString sCell1, CString sCell2) // rsh
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetColumnInNumber3DotFormat:[%s-%s]", sCell1, sCell2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oRange.SetNumberFormatLocal(COleVariant("0.000_ ")); 
}

void CMSExcel::SetCellInNumber2DotFormat(short iRow1, short iCol1, short iRow2, short iCol2) // rsh
{
	CString sCell1 = GetCell(iRow1, iCol1);
	CString sCell2 = GetCell(iRow2, iCol2);
	SetCellInNumber2DotFormat(sCell1, sCell2);
}

void CMSExcel::SetCellInNumber2DotFormat(CString sCell1, CString sCell2) // rsh
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetCellInNumber2DotFormat:[%s-%s]", sCell1, sCell2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oRange.SetNumberFormatLocal(COleVariant("0.00_ ")); 
}

void CMSExcel::SetColumnInNumber2DotFormat(short iCol1, short iCol2) // rsh
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetColumnInNumber2DotFormat:[%d-%d]", iCol1, iCol2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	CString sCell1 = GetCell(0, iCol1);
	CString sCell2 = GetCell((short)65535, iCol2);

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oRange.SetNumberFormatLocal(COleVariant("0.00_ ")); 
}

void CMSExcel::SetColumnInTextFormat(short iRow1, short iCol1, short iRow2, short iCol2) // rsh
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetColumnInTextFormat:[%d,%d-%d,%d]", iRow1, iCol1, iRow2, iCol2);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	CString sCell1 = GetCell(iRow1, iCol1);
	CString sCell2 = GetCell(iRow2, iCol2);

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	oRange.SetNumberFormatLocal(COleVariant("@"));
}

void CMSExcel::SetDisplayZeros(bool bZero)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetDisplayZeros:%s", (bZero ? "TRUE" : "FALSE"));  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	oWindow = oApp.GetActiveWindow();
	oWindow.SetDisplayZeros(bZero);
}

///<Function></Function>
///<para:nPageRow>�� �������� �� ��</para>
void CMSExcel::SetHPageBreak(short nPageRow, short nPrtRow, short nPrtCol)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetHPageBreak:%d-%d-%d", nPageRow, nPrtRow, nPrtCol);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////
	
	try
	{
		oSheet.SetDisplayPageBreaks(TRUE);
		oWindow = oApp.GetActiveWindow();
		oWindow.SetView(xlPageBreakPreview);//������ ������ �̸�����

		XlPageSetup pageSetup = oSheet.GetPageSetup();
		CString sPrt = "A1:" + GetCell(nPrtRow, nPrtCol);

		nPrtRow += 51;//1 Page Default: 51 ��

		CString sPrtArea = "A1:" + GetCell(nPrtRow, nPrtCol);
		pageSetup.SetPrintArea(sPrtArea);

		HPageBreaks hPBs = oSheet.GetHPageBreaks();
		long count = hPBs.GetCount();
		if(count==0) return;

		for(int i=0; i<count; i++)
		{
			HPageBreak hPB = hPBs.GetItem(i+1);

			CString sCell1;
			sCell1.Format("A%d", (i+1)*nPageRow+1);

			LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),vOpt);
			ASSERT(lpDisp);
			oRange.AttachDispatch(lpDisp);

			hPB.SetRefLocation(lpDisp);

			count = hPBs.GetCount();
		}

		pageSetup.SetPrintArea(sPrt);
    pageSetup.DetachDispatch();
	}
	catch(...)
	{}
}

//XlPageOrientation : xlPortrait, xlLandscape          XlPaperSize : xlPaperA3, xlPaperA4, xlPaperB4, xlPaperB5
void CMSExcel::SetPageSetup(XlPageOrientation pageOrt, XlPaperSize paperSize)
{	
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { m_WorkRec.Add_WorkHistory("SetPageSetup"); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	XlPageSetup pageSetup = oSheet.GetPageSetup();
	pageSetup.SetPaperSize(paperSize);
	pageSetup.SetOrientation(pageOrt);
	pageSetup.DetachDispatch();
}

void CMSExcel::SetPageSetupHeader(CString strLeftHeader, CString strCenterHeader, CString strRightHeader)
{	
  // Text ��Ͻ� ///////////////////
  if(m_nRecType == 1 || m_nRecType == 2)
  {// Text ��Ϲ��
    if(m_nRecType == 1)      { m_WorkRec.Add_WorkHistory("SetPageSetupHeader"); }				
    return ;// CMSExcel�� �۾��� ���� ����
  } 
  //////////////////////////////////
  
  XlPageSetup pageSetup = oSheet.GetPageSetup();
  pageSetup.SetLeftHeader(strLeftHeader);
  pageSetup.SetCenterHeader(strCenterHeader);
  pageSetup.SetRightHeader(strRightHeader);
  pageSetup.DetachDispatch();
}

void CMSExcel::SetPageSetupFooter(CString strLeftFooter, CString strCenterFooter, CString strRightFooter)
{	
  // Text ��Ͻ� ///////////////////
  if(m_nRecType == 1 || m_nRecType == 2)
  {// Text ��Ϲ��
    if(m_nRecType == 1)      { m_WorkRec.Add_WorkHistory("SetPageSetupFooter"); }				
    return ;// CMSExcel�� �۾��� ���� ����
  } 
  //////////////////////////////////
  
  XlPageSetup pageSetup = oSheet.GetPageSetup();
  pageSetup.SetLeftFooter(strLeftFooter);
  pageSetup.SetCenterFooter(strCenterFooter);
  pageSetup.SetRightFooter(strRightFooter);
  pageSetup.DetachDispatch();
}

void CMSExcel::SetPageNormalView(bool bNormal)
{
	if(bNormal)
	{
		oWindow = oApp.GetActiveWindow();
		oWindow.SetView(xlNormalView);
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////
///<summary>Chart Sheet�� ���� ��</summary>
///<para>sTargetSheetName: Chart�� ���� ����Ÿ�� �ִ� SheetName</para>
void CMSExcel::AddChart(CString sChartName, ChartData data, CString sTargetSheetName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("AddChart:%s-%s", sChartName, sTargetSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////
	

	LPDISPATCH lpDisp;

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
  oSheets.AttachDispatch(lpDisp);

	lpDisp = oSheets.Add(vOpt,vOpt,COleVariant((short)1), COleVariant((short)xlChart));

	CString sSheetName = oSheet.GetName();

	oChart.AttachDispatch(lpDisp);
	oChart.SetName(sChartName);

	if(sTargetSheetName == "") sTargetSheetName = sSheetName;
	SetActiveSheet(sTargetSheetName);

	MakeChart(data, sSheetName);
}

///<summary>WorkSheet�� Chart�� ���� ��</summary>
///<para>sTargetSheetName: Chart�� ���� ����Ÿ�� �ִ� SheetName</para>
// void CMSExcel::AddChart(ChartData data, short nRow, short nCol, double Width, double Height, CString sTargetSheetName)
// {
// 	LPDISPATCH lpDisp;
// 
// 	lpDisp = oBook.GetSheets();
// 	ASSERT(lpDisp);
//   oSheets.AttachDispatch(lpDisp);
// 
// 	CString sSheetName = oSheet.GetName();
// 	
// 	lpDisp = oSheet.GetRange(COleVariant("A1"),vOpt);
// 	ASSERT(lpDisp);
// 	oRange.AttachDispatch(lpDisp);
// 
// 	double Left = nCol*oRange.GetWidth().dblVal;
// 	double Top  = nRow*oRange.GetHeight().dblVal;
// 
// 	lpDisp = oSheet.ChartObjects(vOpt);
// 	oChartObjs.AttachDispatch(lpDisp);
// 
// 	lpDisp = oChartObjs.Add(Left, Top, Width, Height);
// 	oChartObj.AttachDispatch(lpDisp);
// 
// 	oChart = oChartObj.GetChart();
// 
// 	if(sTargetSheetName == "") sTargetSheetName = sSheetName;
// 	SetActiveSheet(sTargetSheetName);
// 
// 	MakeChart(data, sSheetName);
// }

// 20071224 �������� ������
void CMSExcel::AddChart(ChartData data, short nRow, short nCol, double Width, double Height, CString sTargetSheetName, short nXAxis, short nYAxis)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("AddChart:%d,%d-%g,%g-%s", nRow, nCol, Width, Height, sTargetSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

  LPDISPATCH lpDisp;
  
  lpDisp = oBook.GetSheets();
  ASSERT(lpDisp);
  oSheets.AttachDispatch(lpDisp);
  
  CString sSheetName = oSheet.GetName();
  
  Range oRange;
  lpDisp = oSheet.GetRange(COleVariant("A1"),vOpt);
  ASSERT(lpDisp);
  oRange.AttachDispatch(lpDisp);
  
  double Left = nCol*oRange.GetWidth().dblVal;
  double Top  = nRow*oRange.GetHeight().dblVal;
  
  lpDisp = oSheet.ChartObjects(vOpt);
  oChartObjs.AttachDispatch(lpDisp);
  
  lpDisp = oChartObjs.Add(Left, Top, Width, Height);
  oChartObj.AttachDispatch(lpDisp);
  
  oChart = oChartObj.GetChart();
  
  if(sTargetSheetName == "") sTargetSheetName = sSheetName;
  SetActiveSheet(sTargetSheetName);
  
  MakeChart(data, sSheetName, nXAxis, nYAxis);
}

void CMSExcel::MakeChart(ChartData data, CString sSheetName, short nXAxis, short nYAxis)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("MakeChart:%s", sSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	Range oRange = oSheet.GetRange(COleVariant(data.SourceData), vOpt);
	oChart.SetChartType((long)data.ChartType);
	oChart.SetSourceData(oRange, COleVariant((short)data.PlotBy));

	//Chart ����
	oChart.SetHasTitle(TRUE);
	ChartTitle oChTitle = oChart.GetChartTitle();
	oChTitle.SetText(data.ChartTitle);

	//�迭�̸�
	for(int i=0; i<data.aSeries.GetSize(); i++)
	{
		try
		{
			Series oSeries = oChart.SeriesCollection(COleVariant((short)(i+1)));
			oSeries.SetName(data.aSeries[i]);
		}
		catch(...){}
	}

	//����
	oChart.SetHasLegend(data.bLegend);
	Legend oLeg = oChart.GetLegend();
	oLeg.SetPosition(data.LegendPosition);

	//X ��
	Axis oXAxis = oChart.Axes(COleVariant((short)nXAxis), 1);
	oXAxis.SetHasTitle(TRUE);
  oXAxis.SetMaximumScaleIsAuto(TRUE);
  oXAxis.SetMinimumScaleIsAuto(TRUE);

	if(fabs(data.dXmax)<1.0E+21)
	{
		oXAxis.SetMaximumScaleIsAuto(FALSE);
		oXAxis.SetMaximumScale(data.dXmax);
	}

	if(fabs(data.dXmin)<1.0E+21)
	{
		oXAxis.SetMinimumScaleIsAuto(FALSE);
		oXAxis.SetMinimumScale(data.dXmin);
	}

	if(data.nXunit>0)
	{
		oXAxis.SetMajorUnit(data.nXunit);
	}

	AxisTitle oXTitle = oXAxis.GetAxisTitle();
	oXTitle.SetText(data.xTitle);

	//Y ��
	Axis oYAxis = oChart.Axes(COleVariant((short)nYAxis), 1);
	oYAxis.SetHasTitle(TRUE);

//	if(fabs(data.dYmax)<1.0E+21)  oYAxis.SetMaximumScale(data.dYmax);
//	if(fabs(data.dYmin)<1.0E+21)  oYAxis.SetMinimumScale(data.dYmin);

  oYAxis.SetMaximumScaleIsAuto(TRUE);
  oYAxis.SetMinimumScaleIsAuto(TRUE);

	if(data.nYunit>0)
		oYAxis.SetMajorUnit(data.nYunit);

	AxisTitle oYTitle = oYAxis.GetAxisTitle();
	oYTitle.SetText(data.yTitle);

	//Interior Color
	PlotArea plot = oChart.GetPlotArea();
	Interior itr = plot.GetInterior();
	itr.SetColorIndex(COleVariant(data.color));

	SetActiveSheet(sSheetName);
	
}

void CMSExcel::AddChartXYReverse(ChartData data, short nRow, short nCol, 
                                 double Width, double Height, CString sTargetSheetName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("AddChartXYReverse:%d,%d-%g,%g-%s", nRow, nCol, Width, Height, sTargetSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

  LPDISPATCH lpDisp;

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
  oSheets.AttachDispatch(lpDisp);

	CString sSheetName = oSheet.GetName();

	lpDisp = oSheet.GetRange(COleVariant("A1"),vOpt);
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	double Left = nCol*oRange.GetWidth().dblVal;
	double Top  = nRow*oRange.GetHeight().dblVal;

	lpDisp = oSheet.ChartObjects(vOpt);
	oChartObjs.AttachDispatch(lpDisp);

	lpDisp = oChartObjs.Add(Left, Top, Width, Height);
	oChartObj.AttachDispatch(lpDisp);

	oChart = oChartObj.GetChart();

	if(sTargetSheetName == "") sTargetSheetName = sSheetName;
	SetActiveSheet(sTargetSheetName);

	MakeChartXYReverse(data, sSheetName);
}


void CMSExcel::MakeChartXYReverse(ChartData data, CString sSheetName)
{
	
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("MakeChartXYReverse:%s", sSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	oRange = oSheet.GetRange(COleVariant(data.SourceData), vOpt);
	oChart.SetChartType((long)data.ChartType);
	oChart.SetSourceData(oRange, COleVariant((short)data.PlotBy));

  //Chart ����
	oChart.SetHasTitle(TRUE);
	ChartTitle oChTitle = oChart.GetChartTitle();
	oChTitle.SetText(data.ChartTitle);

	//�迭�̸�
	for(int i=0; i<data.aSeries.GetSize(); i++)
	{
		try
		{
			Series oSeries = oChart.SeriesCollection(COleVariant((short)(i+1)));
			oSeries.SetName(data.aSeries[i]);

      // �迭�������� 
      CString csXRange; 
      CString csYRange; 
      csXRange.Format("\'%s\'!%s:%s",sSheetName, GetCellOrgExp(data.nStRow, data.nStCol+i+1),GetCellOrgExp(data.nEdRow, data.nStCol+i+1));
      csYRange.Format("\'%s\'!%s:%s",sSheetName, GetCellOrgExp(data.nStRow, data.nStCol),GetCellOrgExp(data.nEdRow, data.nStCol));
      //csXRange.Format("%s:%s",GetCell(data.nStRow, data.nStCol+i+1),GetCell(data.nEdRow, data.nStCol+i+1));
      //csYRange.Format("%s:%s",GetCell(data.nStRow, data.nStCol),GetCell(data.nEdRow, data.nStCol));
      
      //Range xRange = oSheet.GetRange(COleVariant(csXRange), vOpt);
      //Range yRange = oSheet.GetRange(COleVariant(csYRange), vOpt);

      // =SERIES("AbsMax-X",'Story Graph'!$K$2:$K$6,'Story Graph'!$L$2:$L$6,1)

      CString csFormula2;
      csFormula2.Format("=SERIES(\"%s\",%s,%s,%d)",data.aSeries[i],csXRange,csYRange,i+1);

      oSeries.SetFormula(csFormula2);
      oSeries.SetFormulaLocal(csFormula2);
		}
		catch(...){}
	}

	//����
	oChart.SetHasLegend(data.bLegend);
	Legend oLeg = oChart.GetLegend();
	oLeg.SetPosition(data.LegendPosition);

	//X ��
	Axis oXAxis = oChart.Axes(COleVariant((short)xlValue), 1);
	oXAxis.SetHasTitle(TRUE);
  oXAxis.SetMaximumScaleIsAuto(TRUE);
  oXAxis.SetMinimumScaleIsAuto(TRUE);

	if(fabs(data.dXmax)<1.0E+21)
	{
		oXAxis.SetMaximumScaleIsAuto(FALSE);
		oXAxis.SetMaximumScale(data.dXmax);
	}

	if(fabs(data.dXmin)<1.0E+21)
	{
		oXAxis.SetMinimumScaleIsAuto(FALSE);
		oXAxis.SetMinimumScale(data.dXmin);
	}

	if(data.nXunit>0)
	{
		oXAxis.SetMajorUnit(data.nXunit);
	}

	AxisTitle oXTitle = oXAxis.GetAxisTitle();
	oXTitle.SetText(data.xTitle);

	//Y ��
	Axis oYAxis = oChart.Axes(COleVariant((short)xlCategory), 1);
	oYAxis.SetHasTitle(TRUE);

//	if(fabs(data.dYmax)<1.0E+21)  oYAxis.SetMaximumScale(data.dYmax);
//	if(fabs(data.dYmin)<1.0E+21)  oYAxis.SetMinimumScale(data.dYmin);

  oYAxis.SetMaximumScaleIsAuto(TRUE);
  oYAxis.SetMinimumScaleIsAuto(TRUE);

	if(data.nYunit>0)
		oYAxis.SetMajorUnit(data.nYunit);

	AxisTitle oYTitle = oYAxis.GetAxisTitle();
	oYTitle.SetText(data.yTitle);

	//Interior Color
	PlotArea plot = oChart.GetPlotArea();
	Interior itr = plot.GetInterior();
	itr.SetColorIndex(COleVariant(data.color));

	SetActiveSheet(sSheetName);

}


///<summary>WorkSheet�� Chart�� ���� ��</summary>
///<para>sTargetSheetName: Chart�� ���� ����Ÿ�� �ִ� SheetName</para>
void CMSExcel::AddChartScatter(ChartData data, short nRow, short nCol, double Width, double Height, CString sTargetSheetName)
{	
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("AddChartScatter:%d,%d-%g,%g-%s", nRow, nCol, Width, Height, sTargetSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp;

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
  oSheets.AttachDispatch(lpDisp);

	CString sSheetName = oSheet.GetName();

	lpDisp = oSheet.GetRange(COleVariant("A1"),vOpt);
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	double Left = nCol*oRange.GetWidth().dblVal;
	double Top  = nRow*oRange.GetHeight().dblVal;

	lpDisp = oSheet.ChartObjects(vOpt);
	oChartObjs.AttachDispatch(lpDisp);

	lpDisp = oChartObjs.Add(Left, Top, Width, Height);
	oChartObj.AttachDispatch(lpDisp);

	oChart = oChartObj.GetChart();

	if(sTargetSheetName == "") sTargetSheetName = sSheetName;
	SetActiveSheet(sTargetSheetName);

	MakeChartScatter(data, sSheetName);
}




void CMSExcel::MakeChartScatter(ChartData data, CString sSheetName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("MakeChartScatter:%s", sSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	oRange = oSheet.GetRange(COleVariant(data.SourceData), vOpt);
	oChart.SetChartType((long)data.ChartType);
	oChart.SetSourceData(oRange, COleVariant((short)data.PlotBy));

  //Chart ����
	oChart.SetHasTitle(TRUE);
	ChartTitle oChTitle = oChart.GetChartTitle();
	oChTitle.SetText(data.ChartTitle);

	// �迭�̸�
  for(int i=0,nSeriesIdx=0; i<data.aSeries.GetSize(); i+=2,nSeriesIdx++)
	{
		try
		{
			Series oSeries = oChart.SeriesCollection(COleVariant((short)(nSeriesIdx+1)));
			oSeries.SetName(data.aSeries[i+1]);

      // �迭�������� 
      CString csXRange; 
      CString csYRange; 
      csXRange.Format("\'%s\'!%s:%s",sSheetName, GetCellOrgExp(data.nStRow, data.nStCol+i),  GetCellOrgExp(data.nEdRow, data.nStCol+i));
      csYRange.Format("\'%s\'!%s:%s",sSheetName, GetCellOrgExp(data.nStRow, data.nStCol+i+1),GetCellOrgExp(data.nEdRow, data.nStCol+i+1));
      
      CString csFormula2;
      csFormula2.Format("=SERIES(\"%s\",%s,%s,%d)",data.aSeries[i+1],csXRange,csYRange,nSeriesIdx+1);

      oSeries.SetFormula(csFormula2);
      oSeries.SetFormulaLocal(csFormula2);
		}
		catch(...){}
	}

	//����
	oChart.SetHasLegend(data.bLegend);
	Legend oLeg = oChart.GetLegend();
	oLeg.SetPosition(data.LegendPosition);

	//X ��
	Axis oXAxis = oChart.Axes(COleVariant((short)xlCategory), 1);
	oXAxis.SetHasTitle(TRUE);
  oXAxis.SetMaximumScaleIsAuto(TRUE);
  oXAxis.SetMinimumScaleIsAuto(TRUE);

	if(fabs(data.dXmax)<1.0E+21)
	{
		oXAxis.SetMaximumScaleIsAuto(FALSE);
		oXAxis.SetMaximumScale(data.dXmax);
	}

	if(fabs(data.dXmin)<1.0E+21)
	{
		oXAxis.SetMinimumScaleIsAuto(FALSE);
		oXAxis.SetMinimumScale(data.dXmin);
	}

	if(data.nXunit>0)
	{
		oXAxis.SetMajorUnit(data.nXunit);
	}

	AxisTitle oXTitle = oXAxis.GetAxisTitle();
	oXTitle.SetText(data.xTitle);

	//Y ��
	Axis oYAxis = oChart.Axes(COleVariant((short)xlValue), 1);
	oYAxis.SetHasTitle(TRUE);

  oYAxis.SetMaximumScaleIsAuto(TRUE);
  oYAxis.SetMinimumScaleIsAuto(TRUE);

	if(data.nYunit>0)
		oYAxis.SetMajorUnit(data.nYunit);

	AxisTitle oYTitle = oYAxis.GetAxisTitle();
	oYTitle.SetText(data.yTitle);

	//Interior Color
	PlotArea plot = oChart.GetPlotArea();
	Interior itr = plot.GetInterior();
	itr.SetColorIndex(COleVariant(data.color));

	SetActiveSheet(sSheetName);
}


///<summary>WorkSheet�� Chart�� ���� ��</summary>
///<para>sTargetSheetName: Chart�� ���� ����Ÿ�� �ִ� SheetName</para>
void CMSExcel::AddChartLine(ChartData data, short nRow, short nCol, 
                            double Width, double Height, CString sTargetSheetName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("AddChartLine:%d,%d-%g,%g-%s", nRow, nCol, Width, Height, sTargetSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp;

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
  oSheets.AttachDispatch(lpDisp);

	CString sSheetName = oSheet.GetName();

	lpDisp = oSheet.GetRange(COleVariant("A1"),vOpt);
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

	double Left = nCol*oRange.GetWidth().dblVal;
	double Top  = nRow*oRange.GetHeight().dblVal;

	lpDisp = oSheet.ChartObjects(vOpt);
	oChartObjs.AttachDispatch(lpDisp);

	lpDisp = oChartObjs.Add(Left, Top, Width, Height);
	oChartObj.AttachDispatch(lpDisp);

	oChart = oChartObj.GetChart();

	if(sTargetSheetName == "") sTargetSheetName = sSheetName;
	SetActiveSheet(sTargetSheetName);

	MakeChartLine(data, sSheetName);
}

void CMSExcel::MakeChartLine(ChartData data, CString sSheetName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("MakeChartLine:%s", sSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	oRange = oSheet.GetRange(COleVariant(data.SourceData), vOpt);
	oChart.SetChartType((long)data.ChartType);
	oChart.SetSourceData(oRange, COleVariant((short)data.PlotBy));

	//Chart ����
	oChart.SetHasTitle(TRUE);
	ChartTitle oChTitle = oChart.GetChartTitle();
	oChTitle.SetText(data.ChartTitle);

	//�迭�̸�
	for(int i=0; i<data.aSeries.GetSize(); i++)
	{
		try
		{
			Series oSeries = oChart.SeriesCollection(COleVariant((short)(i+1)));
			oSeries.SetName(data.aSeries[i]);
		}
		catch(...){}
	}

	//����
	oChart.SetHasLegend(data.bLegend);
	Legend oLeg = oChart.GetLegend();
	oLeg.SetPosition(data.LegendPosition);

	//X ��
	Axis oXAxis = oChart.Axes(COleVariant((short)xlCategory), 1);
	oXAxis.SetHasTitle(TRUE);
  //oXAxis.SetMaximumScaleIsAuto(TRUE);
  //oXAxis.SetMinimumScaleIsAuto(TRUE);

  /*
	if(fabs(data.dXmax)<1.0E+21)
	{
		oXAxis.SetMaximumScaleIsAuto(FALSE);
		oXAxis.SetMaximumScale(data.dXmax);
	}

	if(fabs(data.dXmin)<1.0E+21)
	{
		oXAxis.SetMinimumScaleIsAuto(FALSE);
		oXAxis.SetMinimumScale(data.dXmin);
	}

	if(data.nXunit>0)
	{
		oXAxis.SetMajorUnit(data.nXunit);
	}
  */

	AxisTitle oXTitle = oXAxis.GetAxisTitle();
	oXTitle.SetText(data.xTitle);

	//Y ��
	Axis oYAxis = oChart.Axes(COleVariant((short)xlValue), 1);
	oYAxis.SetHasTitle(TRUE);

//	if(fabs(data.dYmax)<1.0E+21)  oYAxis.SetMaximumScale(data.dYmax);
//	if(fabs(data.dYmin)<1.0E+21)  oYAxis.SetMinimumScale(data.dYmin);

  oYAxis.SetMaximumScaleIsAuto(TRUE);
  oYAxis.SetMinimumScaleIsAuto(TRUE);

	if(data.nYunit>0)
		oYAxis.SetMajorUnit(data.nYunit);

	AxisTitle oYTitle = oYAxis.GetAxisTitle();
	oYTitle.SetText(data.yTitle);

	//Interior Color
	PlotArea plot = oChart.GetPlotArea();
	Interior itr = plot.GetInterior();
	itr.SetColorIndex(COleVariant(data.color));

	SetActiveSheet(sSheetName);
}

// Add by GAY.('06.02.01) Helper Method
// pDisp �� ũ�� �Ǵ� ������ ��� �Լ�
int CMSExcel::GetPropertyCount(IDispatch* pDisp)
{
	int count = 0;

	if(pDisp != NULL)
	{
		VARIANT result;
		VariantInit(&result);
    
		HRESULT hr = AutoWrap(DISPATCH_PROPERTYGET, &result, pDisp, L"Count", 0);
		if(FAILED(hr))
		{
			::MessageBox(NULL, "IDispatch Count Not Found", "Error", MB_SETFOREGROUND | MB_OK);
			return count;
		}
		count = (int)result.lVal;
	}
	return count;
}

// Add by GAY.('06.02.01) Range ������ ��� ���� ����
// [param] ũ�⸦ �˰��� �ϴ� Range
// [param] Range�� ���
// [param] Range�� ����
void CMSExcel::GetRangeCount(Range range, int& rowCnt, int& colCnt)
{
  rowCnt = GetPropertyCount(range.GetRows());
  colCnt = GetPropertyCount(range.GetColumns());
}


// Add by GAY.('06.02.01) Helper Method
// "http://support.microsoft.com/kb/216686/" ����
// AutoWrap() �Լ��� ���� IDispatch�� ����ϴ� �Ͱ� ���õ� ��κ��� ���� ���� ���� ������ �ܼ�ȭ�մϴ�.
HRESULT CMSExcel::AutoWrap(int autoType, VARIANT *pvResult, IDispatch *pDisp, LPOLESTR ptName, int cArgs...)
{
    // Begin variable-argument list...
    va_list marker;
    va_start(marker, cArgs);

    if(!pDisp) {
		::MessageBox(NULL, "NULL IDispatch passed to AutoWrap()", "Error", 0x10010);
        _exit(0);
    }

    // Variables used...
    DISPPARAMS dp = { NULL, NULL, 0, 0 };
    DISPID dispidNamed = DISPID_PROPERTYPUT;
    DISPID dispID;
    HRESULT hr;
    //char buf[200];
    char szName[200];

    // Convert down to ANSI
    WideCharToMultiByte(CP_ACP, 0, ptName, -1, szName, 256, NULL, NULL);

    // Get DISPID for name passed...
    hr = pDisp->GetIDsOfNames(IID_NULL, &ptName, 1, LOCALE_USER_DEFAULT, &dispID);
    if(FAILED(hr)) {
//        sprintf(buf, "IDispatch::GetIDsOfNames(\"%s\") failed w/err 0x%08lx", szName, hr);
//		::MessageBox(NULL, buf, "AutoWrap()", 0x10010);
//        _exit(0);
        return hr;
    }

    // Allocate memory for arguments...
    VARIANT *pArgs = new VARIANT[cArgs+1];
    // Extract arguments...
    for(int i=0; i<cArgs; i++) {
        pArgs[i] = va_arg(marker, VARIANT);
    }

    // Build DISPPARAMS
    dp.cArgs = cArgs;
    dp.rgvarg = pArgs;

    // Handle special-case for property-puts!
    if(autoType & DISPATCH_PROPERTYPUT) {
        dp.cNamedArgs = 1;
        dp.rgdispidNamedArgs = &dispidNamed;
    }

    // Make the call!
    hr = pDisp->Invoke(dispID, IID_NULL, LOCALE_SYSTEM_DEFAULT, autoType, &dp, pvResult, NULL, NULL);
    if(FAILED(hr)) {
//        sprintf(buf, "IDispatch::Invoke(\"%s\"=%08lx) failed w/err 0x%08lx", szName, dispID, hr);
//		::MessageBox(NULL, buf, "AutoWrap()", 0x10010);
//        _exit(0);
        return hr;
    }
    
    // End variable-argument section...
    va_end(marker);

    delete [] pArgs;

    return hr;
}

// Add by GAY.('06.02.01) ���� Sheet ���� Hyper Link �����ϱ�
// [param] ancCell : HyperLink�� Anchor Cell
// [param] lnkCell : HyperLink�� ������ Cell
void CMSExcel::SetHyperLink(CString ancCell, CString lnkCell)
{  
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetHyperLink:[%s]%s", ancCell, lnkCell);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////
	
  LPDISPATCH lpDisp;  
  lpDisp = oSheet.GetHyperlinks();
  ASSERT(lpDisp);
  oHypers.AttachDispatch(lpDisp);
  oHypers.Add(oSheet.GetRange(COleVariant(ancCell), COleVariant(ancCell)), "", COleVariant(lnkCell), vOpt, vOpt);
}

// Add by GAY.('06.02.01) �ٸ� Sheet ���� Hyper Link �����ϱ�
// [param] ancCell : HyperLink�� Anchor Cell
// [param] lnkSheetName : HyperLink�� ������ Cell�� ��ġ�� Sheet �̸�
// [param] lnkCell : HyperLink�� ������ Cell
void CMSExcel::SetHyperLink(CString ancCell, CString lnkSheetName, CString lnkCell)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetHyperLink:[%s]%s-%s", ancCell, lnkSheetName, lnkCell);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

  LPDISPATCH lpDisp;  
  lpDisp = oSheet.GetHyperlinks();
  ASSERT(lpDisp);
  oHypers.AttachDispatch(lpDisp);
  CString strCell;
  strCell.Format("%s!%s", lnkSheetName, lnkCell);
  oHypers.Add(oSheet.GetRange(COleVariant(ancCell), COleVariant(ancCell)), "", COleVariant(strCell), vOpt, vOpt);
}

// Add by GAY.('06.02.01) ���� �־��� Cell�� �ٷ� �տ��� Page ������.
// [param] Page�� ���������� ���� Cell �̸�.
void CMSExcel::SetHPageBreakBeforeActiveCell(CString sCell)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetHPageBreakBeforeActiveCell:[%s]", sCell);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

  LPDISPATCH lpDisp;  
  lpDisp = oSheet.GetHPageBreaks();
  ASSERT(lpDisp);
  oHBreaks.AttachDispatch(lpDisp);
  oHBreaks.Add(oSheet.GetRange(COleVariant(sCell), COleVariant(sCell)));
}

// ���� �־��� Cell�� �ٷ� �տ��� Page ������.
// [param] Page�� ���������� ���� Cell Index.
void CMSExcel::SetHPageBreakBeforeActiveCell(short Row, short Col)
{
  CString strCell = GetCell(Row, Col);
  SetHPageBreakBeforeActiveCell(strCell);
}

// Add by GAY.('06.02.01) ���� WorkBook�� �����ϴ� WorkSheet�� ���� ���.
int CMSExcel::GetWorkSheetCount()
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { m_WorkRec.Add_WorkHistory("GetWorkSheetCount"); }	
		return m_WorkRec.GetWorkSheetCount();// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp;
	lpDisp = oBook.GetSheets();

  return GetPropertyCount(lpDisp);
}

// Add by GAY.('06.02.01) Default Sheet �� ���� (�ٸ� Sheet�� �����ϴ� ���)
void CMSExcel::DeleteDefaultSheet()
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { m_WorkRec.Add_WorkHistory("DeleteDefaultSheet"); }	
		m_WorkRec.Del_Sheet("Sheet1");  
		m_WorkRec.Del_Sheet("Sheet2");
		m_WorkRec.Del_Sheet("Sheet3");
		return;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

  CString strDefaultSheet[3] = { "Sheet1", "Sheet2", "Sheet3" };

  for(int i=0; i<3; i++)
  {
    if(IsExistSheetName(strDefaultSheet[i]))
    {
      DeleteSheet(strDefaultSheet[i]);
    }
  }

  /*
  if(GetWorkSheetCount() > 3)
  {
    DeleteSheet("Sheet1");
    DeleteSheet("Sheet2");
    DeleteSheet("Sheet3");
  }
  */
}

// �ش� Cell�� ����� ���� Format���� ����.
void CMSExcel::SetCellInUserFormat(CString sCell1, CString sCell2, CString sFormat)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetCellInUserFormat:[%s-%s]%s", sCell1, sCell2, sFormat);  m_WorkRec.Add_WorkHistory(strTemp); }	
		return;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	oRange.SetNumberFormatLocal(COleVariant(sFormat)); 
}


// �ش� Cell�� ����� ���� Format���� ���.
void CMSExcel::SetValueInUserFormat(CString sCell, CString sVal, CString sFormat)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetValueInUserFormat:[%s]%s-%s", sCell, sVal, sFormat);  m_WorkRec.Add_WorkHistory(strTemp); }	
		else if(m_nRecType == 2) { short nRow, nCol;  GetCellID(sCell, nRow, nCol);                    m_WorkRec.Add_SheetItem(nRow, nCol, sVal); }
		return;// CMSExcel�� �۾��� ���� ����
	} 
	//////////////////////////////////

	LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell),vOpt);
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	oRange.SetValue(COleVariant(sVal));
  oRange.SetNumberFormatLocal(COleVariant(sFormat));
}


// �׸������� �ش� Cell�� ���̱�.
void CMSExcel::AddPicture(CString sPicName, short Row, short Col, float Width, float Height, int& rowCnt)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("AddPicture:[%d,%d]%s-%g,%g", Row, Col, sPicName, Width, Height);  m_WorkRec.Add_WorkHistory(strTemp); }		
		rowCnt = (int)(Height*GetValueFromMilimeterToPoint() / 13.5 - 0.5) + 1;
		return ;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

 	LPDISPATCH lpDisp;
	
  CString sCell = GetCell(Row, Col);
	lpDisp = oSheet.GetRange(COleVariant(sCell), vOpt);
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
  
	float Wi = (float)oRange.GetWidth().dblVal;
	float He = (float)oRange.GetHeight().dblVal;

	lpDisp = oSheet.GetShapes();	
	ASSERT(lpDisp);
	oShapes.AttachDispatch(lpDisp);

  float Left = Wi * Col;
	float Top  = He * Row;

  Width  *= GetValueFromMilimeterToPoint();
  Height *= GetValueFromMilimeterToPoint();

	lpDisp = oShapes.AddPicture(sPicName, FALSE, TRUE, Left, Top, Width, Height);
	//lpDisp->Release();
  
  rowCnt = (int)(Height / He - 0.5) + 1;  
}

// �׸� ũ�⸦ Excel ���� ũ��� ��ȯ�ϱ� ���� Factor.
double CMSExcel::GetValueFromMilimeterToPoint()
{
  return 72.0 / 25.4;   // 1inch = 2.54cm = 72point
}

// Set Page Margin.
void CMSExcel::SetMargin(double dLeft, double dRight, double dTop, double dBot)
{  
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetMargin:%g-%g-%g-%g", dLeft, dRight, dTop, dBot);  m_WorkRec.Add_WorkHistory(strTemp); }		
		return ;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

	XlPageSetup pageSetup = oSheet.GetPageSetup();
  pageSetup.SetLeftMargin(dLeft * GetValueFromMilimeterToPoint());
  pageSetup.SetRightMargin(dRight * GetValueFromMilimeterToPoint());
  pageSetup.SetTopMargin(dTop * GetValueFromMilimeterToPoint());
  pageSetup.SetBottomMargin(dBot * GetValueFromMilimeterToPoint());
	pageSetup.DetachDispatch();
}

// Insert Picture at Selected Cell.
void CMSExcel::InsertPicture(CString sPicName, short Row, short Col)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("InsertPicture:[%d,%d]%s", Row, Col, sPicName);  m_WorkRec.Add_WorkHistory(strTemp); }		
		return ;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

 	LPDISPATCH lpDisp;

  CString sCell = GetCell(Row, Col);
	lpDisp = oSheet.GetRange(COleVariant(sCell), vOpt);
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
  oRange.Select();

  Pictures oPictures;
  lpDisp = oSheet.GetPictures();
  ASSERT(lpDisp);
  oPictures.AttachDispatch(lpDisp);
  
	//(2008.03.20) Modify by GAY :: ���Ե� �׸��� ��ġ Setting. (Sheet������ ��ǥ��������..)
  lpDisp = oPictures.Insert(sPicName, vOpt);  
  oShape.AttachDispatch(lpDisp);

	float Wi = (float)oRange.GetWidth().dblVal;
	float He = (float)oRange.GetHeight().dblVal;	

  float dLeft = Wi*Col;
  float dTop  = He*Row;
  oShape.SetLeft(dLeft);
  oShape.SetTop(dTop);
}

// ('06.03.14). Change by GAY. �ش��̸��� ���� Sheet�� �����ϴ����� ����.
BOOL CMSExcel::IsExistSheetName(CString strSheetName)
{
  CStringArray arSheetNames;
  GetSheetsName(arSheetNames);
  
  int count = arSheetNames.GetSize();
  for(int i=0; i<count; i++)
  {
    if(arSheetNames.GetAt(i) == strSheetName)
    {
      return TRUE;
    }
  }  
  return FALSE;
}

// ('06.03.15). �ش��̸��� ������ Sheet�� �����ϴ����� ����.
BOOL CMSExcel::IsExistSheetNameInclude(CString strSheetName)
{
  CStringArray arSheetNames;
  GetSheetsName(arSheetNames);
  
  int count = arSheetNames.GetSize();
  for(int i=0; i<count; i++)
  {
    if(arSheetNames.GetAt(i).Find(strSheetName) > -1)
    {
      return TRUE;
    }
  }  
  return FALSE;
}

//('06.03.15). �ش��̸��� ������ Sheet ��, ���� �� �̸� ��������.
CString CMSExcel::GetMaximumSheetName(CString strSheetName)
{
  CStringArray arSheetNames;
  GetSheetsName(arSheetNames);
  
  CString result = _T("");
  int count = arSheetNames.GetSize();
  for(int i=0; i<count; i++)
  {
    if(arSheetNames.GetAt(i).Find(strSheetName) > -1)
    {
      if(result.GetLength() < arSheetNames.GetAt(i).GetLength())
      {
        result = arSheetNames.GetAt(i);
      }
    }
  }  
  return result;
}

void CMSExcel::SetSheetSelection(CString strSheetName) //!!!
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetSheetSelection:%s", strSheetName);  m_WorkRec.Add_WorkHistory(strTemp); }		
		m_WorkRec.Set_Sheet(strSheetName);
		return ;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

	LPDISPATCH lpDisp;

	lpDisp = oBook.GetSheets();
	ASSERT(lpDisp);
	oSheets.AttachDispatch(lpDisp);

	lpDisp = oSheets.GetItem(COleVariant(strSheetName));
	ASSERT(lpDisp);
	oSheet.AttachDispatch(lpDisp);
	oSheet.Select(vOpt);
}

//(2008.03.14) Add by GAY : Excel ���α׷��� Standard Font ����
void CMSExcel::SetStandardFont(CString strFont, int iFontSize)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { m_WorkRec.Add_WorkHistory("SetStandardFont"); }				
		return ;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

  oApp.SetStandardFont(strFont);
  oApp.SetStandardFontSize(iFontSize);
}

void CMSExcel::AddStyle(CString strStyleName, short fontHeight, COLORREF fontColor, CString sFontType, BOOL bFontBold)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("AddStyle:%s", strStyleName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

  LPDISPATCH lpDisp;

  lpDisp = oBook.GetStyles();
  ASSERT(lpDisp);
  oStyles.AttachDispatch(lpDisp);

  try
  {
    lpDisp = oStyles.GetItem(COleVariant(strStyleName));
  }
  catch(CException* e)
  {
    lpDisp = oStyles.Add(strStyleName, vOpt);
    e->Delete(); 
  }
  catch(...)
  {
  }
  
  ASSERT(lpDisp);
  oStyle.AttachDispatch(lpDisp);

  oStyle.SetIncludeFont(TRUE);
  oStyle.SetIncludeNumber(TRUE);
  oStyle.SetIncludeBorder(TRUE);

	oFont = oStyle.GetFont();
	oFont.SetSize(COleVariant((short)fontHeight));
	oFont.SetColor(COleVariant((double)fontColor));
	oFont.SetName(COleVariant(sFontType));

	if(bFontBold)
		oFont.SetBold(vTrue);
	else
		oFont.SetBold(vFalse);
}

void CMSExcel::SetStyle(CString sCell1, CString sCell2, CString strStyleName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetStyle:[%s-%s]", sCell1, sCell2, strStyleName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

  LPDISPATCH lpDisp = oSheet.GetRange(COleVariant(sCell1),COleVariant(sCell2));
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);

  oRange.SetStyle(COleVariant(strStyleName));
}

void CMSExcel::SetStyle(short Row1, short Col1, short Row2, short Col2, CString strStyleName)
{
  CString sCell1 = GetCell(Row1, Col1);
	CString sCell2 = GetCell(Row2, Col2);

  SetStyle(sCell1, sCell2, strStyleName);
}

void CMSExcel::SetSheetStyle(CString strStyleName)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { CString strTemp;   strTemp.Format("SetSheetStyle:%s", strStyleName);  m_WorkRec.Add_WorkHistory(strTemp); }				
		return ;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

  LPDISPATCH lpDisp = oSheet.GetCells();
	ASSERT(lpDisp);
	oRange.AttachDispatch(lpDisp);
	
  oRange.SetStyle(COleVariant(strStyleName));
}


void CMSExcel::SetDefaultStyle(short fontHeight, COLORREF fontColor, CString sFontType, BOOL bFontBold)
{
	// Text ��Ͻ� ///////////////////
	if(m_nRecType == 1 || m_nRecType == 2)
	{// Text ��Ϲ��
		if(m_nRecType == 1)      { m_WorkRec.Add_WorkHistory("SetDefaultStyle"); }				
		return ;// CMSExcel�� �۾��� ���� ����
	}
	//////////////////////////////////

  LPDISPATCH lpDisp;
  
  lpDisp = oBook.GetStyles();
  ASSERT(lpDisp);
  oStyles.AttachDispatch(lpDisp);

  try
  {
    lpDisp = oStyles.GetItem(COleVariant("Normal"));
    ASSERT(lpDisp);
    oStyle.AttachDispatch(lpDisp);

	  oFont = oStyle.GetFont();
	  oFont.SetSize(COleVariant((short)fontHeight));
	  oFont.SetColor(COleVariant((double)fontColor));
	  oFont.SetName(COleVariant(sFontType));

	  if(bFontBold)
		  oFont.SetBold(vTrue);
	  else
		  oFont.SetBold(vFalse);
  }  
  catch(...)
  {
  }  
}

void CMSExcel::ReleaseBeforeSave()
{
  if(oRange.m_lpDispatch)   oRange.ReleaseDispatch();
  if(oFont.m_lpDispatch)    oFont.ReleaseDispatch();
  if(oStyle.m_lpDispatch)   oStyle.ReleaseDispatch();
  if(oStyles.m_lpDispatch)  oStyles.ReleaseDispatch();  
  if(oSheet.m_lpDispatch)   oSheet.ReleaseDispatch();
  if(oSheets.m_lpDispatch)  oSheets.ReleaseDispatch();
  if(oWindow.m_lpDispatch)  oWindow.ReleaseDispatch();  
  if(oWindows.m_lpDispatch)  oWindow.ReleaseDispatch();  
  if(oShape.m_lpDispatch)   oShape.ReleaseDispatch();
  if(oShapes.m_lpDispatch)  oShapes.ReleaseDispatch();  
  if(oChart.m_lpDispatch)   oChart.ReleaseDispatch();
  if(oCharts.m_lpDispatch)  oCharts.ReleaseDispatch();
  if(oChartObjs.m_lpDispatch) oChartObjs.ReleaseDispatch();
  if(oChartObj.m_lpDispatch)  oChartObj.ReleaseDispatch();
  if(oTmpSheet.m_lpDispatch)  oTmpSheet.ReleaseDispatch();
  if(oInterior.m_lpDispatch)  oInterior.ReleaseDispatch();
  if(oBorder.m_lpDispatch)    oBorder.ReleaseDispatch();
  if(oBorders.m_lpDispatch)   oBorders.ReleaseDispatch();
}