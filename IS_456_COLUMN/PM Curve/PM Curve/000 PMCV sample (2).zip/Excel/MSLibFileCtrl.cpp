// MSLibFileCtrl.cpp: implementation of the CMSLibFileCtrl class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MSLibFileCtrl.h"

#include <afxtempl.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#pragma comment (lib, "winmm.lib")    // for GetFileVersion
#pragma comment (lib, "version.lib")  // for GetFileVersion

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMSLibFileCtrl::CMSLibFileCtrl()
{
  CString csNullFile;
	SetFilePathNameExt(csNullFile);
}

CMSLibFileCtrl::CMSLibFileCtrl(LPCTSTR pszFilePathNameExt)
{
	SetFilePathNameExt(pszFilePathNameExt);
}

CMSLibFileCtrl::~CMSLibFileCtrl()
{
}

void CMSLibFileCtrl::SetFilePathNameExt(LPCTSTR pszFilePathNameExt)
{
  CString csPathNameExt;  /* rstrFilePathAndName : c:\midas\gen.exe */
  m_strFilePath.Empty();  /* only path           : c:\midas\        */
  m_strFileName.Empty();  /* only file name      : gen              */
  m_strFileExt.Empty();   /* only extention      : exe              */

  csPathNameExt = pszFilePathNameExt;

	int nStrLength, nFindBackSlash;
	nStrLength=csPathNameExt.GetLength();
	nFindBackSlash=csPathNameExt.ReverseFind('\\');

  CString csFileNameExt;
	if(nFindBackSlash != -1)
	{
		m_strFilePath = csPathNameExt.Left(nFindBackSlash+1);
		csFileNameExt = csPathNameExt.Mid(nFindBackSlash+1);
	}
  else csFileNameExt = csPathNameExt;

	int nFind=csFileNameExt.ReverseFind('.');
	if(nFind == -1)
  {
    m_strFileName = csFileNameExt;
    // m_strFileExt.Empty() // already initialized
  }
  else
	{
		m_strFileName = csFileNameExt.Left(nFind);
		m_strFileExt = csFileNameExt.Mid(nFind+1);
	}
}

CString CMSLibFileCtrl::GetFilePathNameExt()
{
  CString csName;
  csName += m_strFilePath + m_strFileName;
  if (!m_strFileExt.IsEmpty()) csName += "."+m_strFileExt;
	return csName;
}

CString CMSLibFileCtrl::GetFilePathName()
{
	return m_strFilePath + m_strFileName;
}

CString CMSLibFileCtrl::GetFilePath()
{
	return m_strFilePath;
}

CString CMSLibFileCtrl::GetFileNameExt()
{
  CString csName;
  if (!m_strFileExt.IsEmpty()) csName = m_strFileName+"."+m_strFileExt;
  else csName = m_strFileName;
	return csName;
}

CString CMSLibFileCtrl::GetFileName()
{
	return m_strFileName;
}

CString CMSLibFileCtrl::GetFileExt()
{
	return m_strFileExt;
}

CString CMSLibFileCtrl::GetAbbPathNameExt(int nMaxLen)
{
  CString csFile, csPathOnly, csFileNameExt;

  csFile = GetFilePathNameExt();
  csPathOnly = GetFilePath();
  csFileNameExt = GetFileNameExt();
  int nStart = 0;
  int nPos;
  CArray<int, int> aPos;  // Path���� �� ������ ��ġ �� ã�Ƴ���
  while ((nPos = csPathOnly.Find('\\', nStart)) != -1)
  {
    aPos.Add(nPos);
    nStart = nPos+1;
  }
  int nBScount = aPos.GetSize();  // �� ������ ����
  int nRemove = 1;  // ������ �齽���� ��ġ (�� �� °���� ���ŵȴ�.)

  CString csAbbPath = csPathOnly;
  while ((nRemove < nBScount) && csFile.GetLength() > nMaxLen)
  {
    // �߰� Path�� �ϳ� �����Ѵ�.
    csAbbPath = csPathOnly.Left(aPos[0]+1)+"..."+csPathOnly.Mid(aPos[nRemove]);
    nRemove++;

    csFile = csAbbPath+csFileNameExt;
    if (csFile.GetLength() <= nMaxLen) return csFile;
  }
  if (csFile.GetLength() > nMaxLen) csFile = csFileNameExt;

  return csFile;
}

// pDC�� ��Ʈ�� Select�� �� ȣ��Ǿ�� �Ѵ�. 
// Dialog�� ��� CClient dc(this); dc.SelectObject(GetFont());
CString CMSLibFileCtrl::GetAbbPathNameExt(CDC* pDC, LPRECT lpRect)
{
  CString csFile, csPathOnly, csFileNameExt;

  csFile = GetFilePathNameExt();
  csPathOnly = GetFilePath();
  csFileNameExt = GetFileNameExt();

  int nStart = 0;
  int nPos;
  CArray<int, int> aPos;  // Path���� �� ������ ��ġ �� ã�Ƴ���
  while ((nPos = csPathOnly.Find('\\', nStart)) != -1)
  {
    aPos.Add(nPos);
    nStart = nPos+1;
  }
  int nBScount = aPos.GetSize();  // �� ������ ����
  int nRemove = 1;  // ������ �齽���� ��ġ (�� �� °���� ���ŵȴ�.)

  CSize size;
  SIZE s;
  CRect r(lpRect);

  // Full Path �õ�
  size = pDC->GetTextExtent(csFile);
  s.cx = size.cx;
  s.cy = size.cy;
  pDC->LPtoDP(&s);
  CString csAbbPath = csPathOnly;
  while ((nRemove < nBScount) && (s.cx > r.Width()))
  {
    // �߰� Path�� �ϳ� �����Ѵ�.
    csAbbPath = csPathOnly.Left(aPos[0]+1)+"..."+csPathOnly.Mid(aPos[nRemove]);
    nRemove++;

    csFile = csAbbPath+csFileNameExt;
    size = pDC->GetTextExtent(csFile);
    s.cx = size.cx;
    s.cy = size.cy;
    pDC->LPtoDP(&s);
  }
  if (s.cx > r.Width())
    csFile = csFileNameExt;

  return csFile;
}

BOOL CMSLibFileCtrl::FileExists()
{
	CFileStatus FileStatus;
	return CFile::GetStatus(GetFilePathNameExt(), FileStatus);
}

BOOL CMSLibFileCtrl::GetFileStatus(CFileStatus& rFileStatus)
{
	return CFile::GetStatus(GetFilePathNameExt(), rFileStatus);
}

BOOL CMSLibFileCtrl::CopyFile(LPCTSTR lpszOldName, LPCTSTR lpszNewName)
{
  FILE *fold, *fnew;
  int c;
  if((fold = fopen((const char*)lpszOldName, "rb"))==NULL) return FALSE;

  if((fnew = fopen((const char*)lpszNewName, "wb"))==NULL)
  {
    fclose(fold);
    return FALSE;
  }

  while(TRUE)
  {
    c = fgetc(fold);
    if(!feof(fold)) fputc(c,fnew);
    else break;
  }

  fclose(fnew);
  fclose(fold);

  return TRUE;
}

// [2009-03-06] Kim, Geun Young (Tel: 2042, gykim@midasit.com)
// ocx ������ check�ϱ� ���� �Լ�. 
BOOL CMSLibFileCtrl::GetFileInfoString(LPTSTR lptstrFilename, LPCTSTR lptstrQuery, CString &strInfo)
{	
	if(lptstrQuery == "")		
		return FALSE;
	
	DWORD  dwHandle;	
	LPVOID ptr;	
	UINT   uLength;		
	
	DWORD dwVersionInfoSize = GetFileVersionInfoSize(lptstrFilename, &dwHandle);	
	if(dwVersionInfoSize == 0)		
		return FALSE;	
	LPVOID pFileInfo = (LPVOID) HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, dwVersionInfoSize);
	GetFileVersionInfo(lptstrFilename, dwHandle, dwVersionInfoSize, pFileInfo);
	VerQueryValue(pFileInfo, TEXT("\\VarFileInfo\\Translation"), &ptr, &uLength);
	
	WORD *id = (WORD*) ptr;	
	char szString[255];	
	sprintf(szString, "\\StringFileInfo\\%04X%04X\\%s", id[0], id[1], lptstrQuery);
	VerQueryValue(pFileInfo, szString, &ptr, &uLength);
	if(uLength == 0)		
		return FALSE;
	
	char sOut[255];
	memset(sOut, 0x00, 255);
	strcpy(sOut, (char *) ptr);
	HeapFree(GetProcessHeap(), 0, pFileInfo);
	strInfo=sOut;	
	
	return TRUE;
}

