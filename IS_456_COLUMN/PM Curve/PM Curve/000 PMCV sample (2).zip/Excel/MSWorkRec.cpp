// MSWorkRec.cpp: implementation of the CMSWorkRec class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <io.h>
#include <fstream>
#include "MSWorkRec.h"

// D_MS_WORK_REC_UNIT ///////////////////////////////////////////////////////
void D_MS_WORK_REC_UNIT::Initialize(int nHashSize)		
{
	if(List.GetCount() > 0)
		List.RemoveAll();

	if      (nHashSize < 10)    nHashSize = 11;
  else if (nHashSize < 50)    nHashSize = 53;
  else if (nHashSize < 100)   nHashSize = 101;
  else if (nHashSize < 300)   nHashSize = 307;
  else if (nHashSize < 600)   nHashSize = 601;
  else if (nHashSize < 1000)  nHashSize = 1009;
  else if (nHashSize < 3000)  nHashSize = 3001;
  else if (nHashSize < 5000)  nHashSize = 5003;
  else if (nHashSize < 7000)  nHashSize = 7001;
  else if (nHashSize < 10000) nHashSize = 10007;
  else if (nHashSize < 30000) nHashSize = 30011;
  else if (nHashSize < 50000) nHashSize = 50021;
  else if (nHashSize < 70000) nHashSize = 70001;
  else if (nHashSize <100000) nHashSize = 100003;
  else                        nHashSize = 150001;

	List.InitHashTable(nHashSize);
}

D_MS_WORK_REC_UNIT& D_MS_WORK_REC_UNIT::operator = (D_MS_WORK_REC_UNIT& pData)
{	
	int nHashSize = List.GetHashTableSize();
	int nListSize = pData.List.GetCount();
	if(nHashSize < nListSize)
	{ Initialize(nListSize); }
	else
	{ if(List.GetCount() > 0) List.RemoveAll(); }

	UINT nKey;
	CString strTemp;	
	POSITION Pos = pData.List.GetStartPosition();	
	while(Pos)
	{	
		pData.List.GetNextAssoc(Pos,nKey,strTemp);
		List.SetAt(nKey,strTemp);
	}
	return *this;
}
int  D_MS_WORK_REC_UNIT::GetKeyList(CArray<UINT, UINT>& arKey)
{
	arKey.RemoveAll();

	int nCount = List.GetCount();
	if(nCount == 0) return 0;
	arKey.SetSize(nCount);

	nCount = 0;
	UINT nKey;
	CString strTemp;	
	POSITION Pos = List.GetStartPosition();	
	while(Pos)
	{	
		List.GetNextAssoc(Pos,nKey,strTemp);
		arKey.SetAt(nCount, nKey);
		nCount++;		
	}
	return arKey.GetSize();
}

// D_MS_WORK_REC_SHEET ///////////////////////////////////////////////////////

void D_MS_WORK_REC_SHEET::Initialize(int nHashSize)		
{
	if(List.GetCount() > 0)
		DestroyItem();
	
	if      (nHashSize < 10)    nHashSize = 11;
  else if (nHashSize < 50)    nHashSize = 53;
  else if (nHashSize < 100)   nHashSize = 101;
  else if (nHashSize < 300)   nHashSize = 307;
  else if (nHashSize < 600)   nHashSize = 601;
  else if (nHashSize < 1000)  nHashSize = 1009;
  else if (nHashSize < 3000)  nHashSize = 3001;
  else if (nHashSize < 5000)  nHashSize = 5003;
  else if (nHashSize < 7000)  nHashSize = 7001;
  else if (nHashSize < 10000) nHashSize = 10007;
  else if (nHashSize < 30000) nHashSize = 30011;
  else if (nHashSize < 50000) nHashSize = 50021;
  else if (nHashSize < 70000) nHashSize = 70001;
  else if (nHashSize <100000) nHashSize = 100003;
  else                        nHashSize = 150001;

	List.InitHashTable(nHashSize);
}

D_MS_WORK_REC_SHEET& D_MS_WORK_REC_SHEET::operator = (D_MS_WORK_REC_SHEET& pData)
{	
	int nHashSize = List.GetHashTableSize();
	int nListSize = pData.List.GetCount();
	if(nHashSize < nListSize)
	{ Initialize(nListSize); }
	else
	{ if(List.GetCount() > 0) DestroyItem(); }

	UINT nKey;
	D_MS_WORK_REC_UNIT* pRecTemp;		
	POSITION Pos = pData.List.GetStartPosition();	
	while(Pos)
	{	
		pData.List.GetNextAssoc(Pos,nKey,pRecTemp);
		D_MS_WORK_REC_UNIT* pRecUnit = new D_MS_WORK_REC_UNIT;	
		*pRecUnit = *pRecTemp;
		List.SetAt(nKey,pRecUnit);
	}
	return *this;
}

void D_MS_WORK_REC_SHEET::DestroyItem()
{
	if(List.GetCount() == 0) return;
	
	UINT nKey;
	D_MS_WORK_REC_UNIT* pMsWorkRecUnit;
	POSITION Pos = List.GetStartPosition();	
	while(Pos)
	{	
		List.GetNextAssoc(Pos,nKey,pMsWorkRecUnit);
		pMsWorkRecUnit->List.RemoveAll();
		delete pMsWorkRecUnit;
	}
	List.RemoveAll();
}

int  D_MS_WORK_REC_SHEET::GetKeyList(CArray<UINT, UINT>& arKey)
{
	arKey.RemoveAll();

	int nCount = List.GetCount();
	if(nCount == 0) return 0;
	arKey.SetSize(nCount);

	nCount = 0;
	UINT nKey;
	D_MS_WORK_REC_UNIT* pRecTemp;		
	POSITION Pos = List.GetStartPosition();	
	while(Pos)
	{	
		List.GetNextAssoc(Pos,nKey,pRecTemp);
		arKey.SetAt(nCount, nKey);
		nCount++;		
	}
	return arKey.GetSize();
}

void D_MS_WORK_REC_SHEET::RemoveKey(UINT key)
{
	D_MS_WORK_REC_UNIT* pRecTemp;		
	if(List.Lookup(key, pRecTemp))
	{
		pRecTemp->List.RemoveAll();
		delete pRecTemp;
		List.RemoveKey(key);
	}
}

// D_MS_WORK_REC_BOOK ///////////////////////////////////////////////////////

void D_MS_WORK_REC_BOOK::Initialize(int nHashSize)		
{
	if(List.GetCount() > 0)
		DestroyItem();

	if      (nHashSize < 10)    nHashSize = 11;
  else if (nHashSize < 50)    nHashSize = 53;
  else if (nHashSize < 100)   nHashSize = 101;
  else if (nHashSize < 300)   nHashSize = 307;
  else if (nHashSize < 600)   nHashSize = 601;
  else if (nHashSize < 1000)  nHashSize = 1009;
  else if (nHashSize < 3000)  nHashSize = 3001;
  else if (nHashSize < 5000)  nHashSize = 5003;
  else if (nHashSize < 7000)  nHashSize = 7001;
  else if (nHashSize < 10000) nHashSize = 10007;
  else if (nHashSize < 30000) nHashSize = 30011;
  else if (nHashSize < 50000) nHashSize = 50021;
  else if (nHashSize < 70000) nHashSize = 70001;
  else if (nHashSize <100000) nHashSize = 100003;
  else                        nHashSize = 150001;

	List.InitHashTable(nHashSize);
	nActSheetID = 0;
}

D_MS_WORK_REC_BOOK& D_MS_WORK_REC_BOOK::operator = (D_MS_WORK_REC_BOOK& pData)
{	
	int nHashSize = List.GetHashTableSize();
	int nListSize = pData.List.GetCount();
	if(nHashSize < nListSize)
	{ Initialize(nListSize); }
	else
	{ if(List.GetCount() > 0) DestroyItem(); }

	UINT nKey;
	D_MS_WORK_REC_SHEET* pRecTemp;		
	POSITION Pos = pData.List.GetStartPosition();	
	while(Pos)
	{	
		pData.List.GetNextAssoc(Pos,nKey,pRecTemp);
		D_MS_WORK_REC_SHEET* pRecUnit = new D_MS_WORK_REC_SHEET;	
		*pRecUnit = *pRecTemp;
		List.SetAt(nKey,pRecUnit);
	}
	nActSheetID = pData.nActSheetID;
	return *this;
}

void D_MS_WORK_REC_BOOK::DestroyItem()
{
	nActSheetID = 0;
	if(List.GetCount() == 0) return;
	
	UINT nKey;
	D_MS_WORK_REC_SHEET* pMsWorkRecSheet;
	POSITION Pos = List.GetStartPosition();	
	while(Pos)
	{	
		List.GetNextAssoc(Pos,nKey,pMsWorkRecSheet);
		
		UINT nKeySub;
		D_MS_WORK_REC_UNIT* pMsWorkRecUnit;
		POSITION PosSub = pMsWorkRecSheet->List.GetStartPosition();	
		while(PosSub)
		{	
			pMsWorkRecSheet->List.GetNextAssoc(PosSub,nKeySub,pMsWorkRecUnit);
			pMsWorkRecUnit->List.RemoveAll();
			delete pMsWorkRecUnit;
		}

		pMsWorkRecSheet->List.RemoveAll();
		delete pMsWorkRecSheet;
	}
	List.RemoveAll();
	nActSheetID = 0;
}

int  D_MS_WORK_REC_BOOK::GetKeyList(CArray<UINT, UINT>& arKey)
{
	arKey.RemoveAll();

	int nCount = List.GetCount();
	if(nCount == 0) return 0;
	arKey.SetSize(nCount);

	nCount = 0;
	UINT nKey;
	D_MS_WORK_REC_SHEET* pRecTemp;		
	POSITION Pos = List.GetStartPosition();	
	while(Pos)
	{	
		List.GetNextAssoc(Pos,nKey,pRecTemp);
		arKey.SetAt(nCount, nKey);
		nCount++;		
	}
	return arKey.GetSize();
}

UINT D_MS_WORK_REC_BOOK::GetNewKey(BOOL bMax)
{
	CArray<UINT, UINT> arKey;
	int nSize = GetKeyList(arKey);
	UINT newKey = 1;
	BOOL bFind = TRUE;

	if(bMax)
	{
		for(int i=0 ; i<nSize ; i++)
		{
			if(newKey <= arKey.GetAt(i))
			{ newKey = arKey.GetAt(i)+1; }
		}
	}
	else 
	{
		while(bFind)
		{
			bFind = FALSE;
			for(int i=0 ; i<nSize ; i++)
			{
				if(newKey == arKey.GetAt(i))
				{ bFind = TRUE;   break; }
			}
			if(bFind)newKey++;
		}
	}
	return newKey;
}
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMSWorkRec::CMSWorkRec()
{
	m_bRowNumOut = TRUE;
	m_bColumnNumOut = TRUE;
	m_nType  = 0;
	m_nCount = 0;	
	m_nBookCount = 0;
	m_nActBookID = 0;
}

CMSWorkRec::~CMSWorkRec()
{
	m_WorkHistory.List.RemoveAll();
	DestroySheetMap();
}

void CMSWorkRec::Initialize(int nType, BOOL bRowNumOut, BOOL bColumnNumOut)
{
	m_nCount = 0;
	m_nBookCount = 0;
	m_nActBookID = 0;
	m_bRowNumOut = bRowNumOut;
	m_bColumnNumOut = bColumnNumOut;
	if(nType == 1)
	{
		m_WorkHistory.Initialize(3001);
		m_BookMap.InitHashTable(53);
		m_nType = nType;
	}
	else if(nType == 2)
	{		
		m_BookMap.InitHashTable(53);
		m_nType = nType;
	}
	else 
	{
		m_nType = 0;
	}
}

BOOL CMSWorkRec::TextOut(CString& strFileName, CString strBookName)
{
	// Data �������� Ȯ��
	if(m_nType == 1)
	{
		if(m_WorkHistory.List.GetCount() <= 0) return FALSE;
	}
	else if(m_nType == 2)
	{
		if(m_BookMap.GetCount() <= 0) return FALSE;
		if(strBookName = "")
		{ if(m_nActBookID <= 0) return FALSE; }
		else 
		{ if(Find_BookID(strBookName) <= 0) return FALSE; }
	}
	else return FALSE;
			
	// ���ϸ��� Text�� ���� �� ���������� ���ϸ����� ����
	CString strFileNameOnly = "";
	int i;
	int nLength = strFileName.GetLength();
	for(i=nLength-1 ; i>=0 ; i--)
	{
		if(strFileName.GetAt(i) == '\\') break;
		if(strFileName.GetAt(i) == '.')
		{ strFileNameOnly = strFileName.Left(i);  break; }
		if(i==0)
		{ strFileNameOnly = strFileName;   break; }
	}
	if(strFileNameOnly == "") strFileNameOnly = (strFileName == "") ? "Temp" : strFileName;
	strFileName = strFileNameOnly + ".txt";

	DeleteFile(strFileName);
	if(_access(strFileName, 0) == 0)
	{
		for(int i=1 ; i<=100 ; i++)
		{
			strFileName.Format("%s_%d.txt", strFileNameOnly, i);			
			DeleteFile(strFileName);
			if(_access(strFileName, 0) != 0)
			{
				strFileNameOnly.Format("%s_%d", strFileNameOnly, i);
				break;				
			}
		}		
	}
	
	// ���ϳ��� ������ �����ϰ� �۾������� �����
  std::ofstream fout;
  fout.open(strFileName, std::ios::out | std::ios::trunc);
	int nSheetSize, nColSize, nRowSize, j, k;
	CString strTemp, strValue, strValueTemp;
	UINT    key, sheetKey, colKey;
	if(m_nType == 1)
	{
		CArray<UINT, UINT> arKey;
		nColSize = m_WorkHistory.GetKeyList(arKey);
		SortKeyList(arKey);		
		for(i=0 ; i<nColSize ; i++)
		{
			key = arKey.GetAt(i);
			if(m_WorkHistory.List.Lookup(key, strValue))
			{
				if(m_bRowNumOut) 
				{				
					if(key < 10000) strTemp.Format("%4d>  %s", key, strValue);
					else           strTemp.Format("%d>  %s", key, strValue);
				}
				else 
				{ strTemp = strValue; }
        fout<<strTemp<<std::endl;					
			}			
		}		
	}
	else if(m_nType == 2)
	{		
		int nOldBookID = m_nActBookID;
		if(strBookName != "") Set_Book(strBookName);
		else                  strBookName = GetBookName(); 

		CArray<UINT, UINT> arSheetKey;
		CArray<UINT, UINT> arColKey;
		CArray<UINT, UINT> arRowKey;

		D_MS_WORK_REC_BOOK* pBookTemp;
		if(m_BookMap.Lookup(m_nActBookID, pBookTemp))
		{		
			nSheetSize = GetSheetKeyList(arSheetKey);
			SortKeyList(arSheetKey);
			for(i=0 ; i<nSheetSize ; i++)
			{
				sheetKey = arSheetKey.GetAt(i);
				D_MS_WORK_REC_SHEET* pSheetTemp;		
				if(pBookTemp->List.Lookup(sheetKey, pSheetTemp))
				{
					nColSize = pSheetTemp->GetKeyList(arColKey);
					if(nColSize <= 0) continue;
					SortKeyList(arColKey);
					
					strTemp.Format("* %s [Sheet:%d] **********************************************", pSheetTemp->strName, sheetKey);
          fout<<strTemp<<std::endl;					
					
					for(j=0; j<nColSize ; j++)
					{
						colKey = arColKey.GetAt(j);
						D_MS_WORK_REC_UNIT* pRecTemp;
						if(pSheetTemp->List.Lookup(colKey, pRecTemp))
						{
							nRowSize = pRecTemp->GetKeyList(arRowKey);
							if(nRowSize <= 0) continue;
							SortKeyList(arRowKey);
							
							if(colKey < 10000) strTemp.Format("%4d>  ", colKey);
							else              strTemp.Format("%d>  ", colKey);
							if(m_bRowNumOut) fout<<strTemp;
							
							for(k=0 ; k<nRowSize ; k++)
							{
								key = arRowKey.GetAt(k);
								if(pRecTemp->List.Lookup(key, strValue))
								{
									if(strValue.Find('\n') >= 0)
									{
										strValueTemp = "";
										int nSize = strValue.GetLength();
										for(int m=0 ; m<nSize ; m++)
										{
											if(strValue.GetAt(m) == '\n')
												strValueTemp += "\\n";
											else 
												strValueTemp += strValue.GetAt(m);
										}
										strValue = strValueTemp;
									}
									if(m_bColumnNumOut) strTemp.Format("[%d] %s,  ", key, strValue);
									else                strTemp.Format("%s,  ", strValue);
									fout<<strTemp;
								}
							}						
              fout<<std::endl;
						}
					}
				}			
			}		
		}
		m_nActBookID = nOldBookID;
	}

	fout.close();
	return TRUE;
}

void CMSWorkRec::Set_Book(CString strBookName)
{
	if(!(m_nType == 1 || m_nType == 2)) return;

	UINT nActBookID = Find_BookID(strBookName);	
	if(nActBookID > 0)
	{ m_nActBookID = nActBookID; }
	else 
	{ m_nActBookID = Add_Book(strBookName); }
}

int CMSWorkRec::Add_Book(CString strBookName, BOOL bActBook)
{
	if(!(m_nType == 1 || m_nType == 2)) return 0;

	if(strBookName == "")
	{
		for(int i=1 ; i<100 ; i++)
		{
			strBookName.Format("Book%d", i);
			if(Find_BookID(strBookName) <= 0) break;
			if(i==99) ASSERT(0);
		}
	}

	int nFindID = Find_BookID(strBookName);
	if(nFindID > 0) 
	{
		if(bActBook) m_nActBookID = nFindID;
		return nFindID;
	}

	D_MS_WORK_REC_BOOK* pBook = new D_MS_WORK_REC_BOOK;
	pBook->Initialize();
	pBook->strName = strBookName;

	m_nBookCount++;
	m_BookMap.SetAt(m_nBookCount, pBook);
	if(bActBook) m_nActBookID = m_nBookCount;
	return m_nBookCount;
}

CString CMSWorkRec::GetBookName()
{
	if(!(m_nType == 1 || m_nType == 2)) return "";

	D_MS_WORK_REC_BOOK* pBook;
	if(m_BookMap.Lookup(m_nActBookID, pBook))
	{ return pBook->strName; }
	return "";
}

void CMSWorkRec::Set_Sheet(CString strSheetName)
{
	if(!(m_nType == 1 || m_nType == 2)) return;

	D_MS_WORK_REC_BOOK* pBook;
	if(m_BookMap.Lookup(m_nActBookID, pBook))
	{
		UINT nActSheetID = Find_SheetID(strSheetName);
		
		if(pBook->nActSheetID > 0)
		{ pBook->nActSheetID = nActSheetID; }
		else
		{ Add_Sheet(strSheetName, TRUE, FALSE); }
	}
}

int CMSWorkRec::Add_Sheet(CString strSheetName, BOOL bActSheet, BOOL bFront)
{
	if(!(m_nType == 1 || m_nType == 2)) return 0;

	D_MS_WORK_REC_BOOK* pBook;
	if(m_BookMap.Lookup(m_nActBookID, pBook))
	{
		int nFindID = Find_SheetID(strSheetName);
		if(nFindID > 0) 
		{
			if(bActSheet) pBook->nActSheetID = nFindID;
			return nFindID;
		}

		D_MS_WORK_REC_SHEET* pSheet = new D_MS_WORK_REC_SHEET;
		pSheet->Initialize();
		pSheet->strName = strSheetName;

		UINT newKey;
		if(!bFront)
		{
			newKey = pBook->GetNewKey(TRUE);	
			pBook->List.SetAt(newKey, pSheet);
		}
		else 
		{
			newKey = 1;
			UINT limKey = pBook->GetNewKey(FALSE);
			UINT nKey;
			D_MS_WORK_REC_SHEET* pSheetTemp;
			for(nKey=limKey-1 ; nKey>0 ; nKey--)
			{
				pBook->List.Lookup(nKey, pSheetTemp);
				pBook->List.SetAt(nKey+1, pSheetTemp);
				pBook->List.RemoveKey(nKey);
			}
			pBook->List.SetAt(newKey, pSheet);
		}
		
		if(bActSheet) pBook->nActSheetID = newKey;
		return newKey;
	}
	return 0;
}

void CMSWorkRec::Del_Sheet(CString strSheetName)
{
	if(!(m_nType == 1 || m_nType == 2)) return;

	D_MS_WORK_REC_BOOK* pBook;
	if(m_BookMap.Lookup(m_nActBookID, pBook))
	{
		UINT nFindID = Find_SheetID(strSheetName);
		if(nFindID <= 0)  return;

		if(pBook->nActSheetID == nFindID)
		{
			CArray<UINT, UINT> arKey;
			int nSize = pBook->GetKeyList(arKey);
			SortKeyList(arKey);
			for(int i=0 ; i<nSize ; i++)
			{
				if(nFindID == arKey[i])
				{					
					if(i < nSize-1)
					{	pBook->nActSheetID = arKey[i+1]; }										
					else 
					{
						if(nSize-2 >= 0) pBook->nActSheetID = arKey[nSize-2];
						else             pBook->nActSheetID = 0;
					}
				}
			}
		}
		
		D_MS_WORK_REC_SHEET* pSheet;
		if(pBook->List.Lookup(nFindID, pSheet))
		{
			pSheet->DestroyItem();
			delete pSheet;
			pBook->List.RemoveKey(nFindID);
		}
	}
}

void CMSWorkRec::MoveSheet(CString sSheetAfter, CString sSheetName)
{
	if(!(m_nType == 1 || m_nType == 2)) return;

	D_MS_WORK_REC_BOOK* pBook;
	if(!m_BookMap.Lookup(m_nActBookID, pBook)) return;
	
	UINT nSheetAfterID = Find_SheetID(sSheetAfter);
	UINT nSheetID = Find_SheetID(sSheetName);
	if(nSheetAfterID == 0 || nSheetID == 0) return;
	if(nSheetAfterID == nSheetID) return;

	BOOL bChkActID = (pBook->nActSheetID == nSheetID);
	
	CArray<UINT, UINT> arKey;
	UINT nKey, nChangeKey;
	D_MS_WORK_REC_SHEET* pSheet;
	D_MS_WORK_REC_SHEET* pSheetTemp;
	if(!pBook->List.Lookup(nSheetID, pSheet)) return;
	pBook->List.RemoveKey(nSheetID);// Sheet ������������ �޾� ���� �ش� Key�� ������
	int nSize = pBook->GetKeyList(arKey);
	SortKeyList(arKey);
	if(nSheetAfterID > nSheetID)
	{// sSheetName�� sSheetAfter �տ� �����ϴ� ���
		nChangeKey = nSheetAfterID;
		for(int i=0 ; i<nSize ; i++)
		{
			nKey = arKey.GetAt(i);
			if(nKey <= nSheetID || nKey > nSheetAfterID) continue;
			if(!pBook->List.Lookup(nKey, pSheetTemp)) continue;
			pBook->List.RemoveKey(nKey);
			pBook->List.SetAt(nKey-1, pSheetTemp);		
			if(pBook->nActSheetID == nKey) pBook->nActSheetID = nKey-1;
		}
	}
	else 
	{// sSheetName�� sSheetAfter �ڿ� �����ϴ� ���
		nChangeKey = nSheetAfterID+1;
		for(int i=nSize-1 ; i>=0 ; i--)
		{
			nKey = arKey.GetAt(i);
			if(nKey <= nSheetAfterID || nKey >= nSheetID) continue;
			if(!pBook->List.Lookup(nKey, pSheetTemp)) continue;
			pBook->List.RemoveKey(nKey);
			pBook->List.SetAt(nKey+1, pSheetTemp);	
			if(pBook->nActSheetID == nKey) pBook->nActSheetID = nKey+1;
		}
	}
	pBook->List.SetAt(nChangeKey, pSheet);	
	if(bChkActID) pBook->nActSheetID = nChangeKey;
	return;
}

void CMSWorkRec::CopySheet(CString sSheetAfter, CString sSheetName)
{
	if(!(m_nType == 1 || m_nType == 2)) return;
	
	D_MS_WORK_REC_BOOK* pBook;
	if(!m_BookMap.Lookup(m_nActBookID, pBook)) return;
	
	UINT nSheetAfterID = Find_SheetID(sSheetAfter);
	UINT nSheetID = Find_SheetID(sSheetName);
	if(nSheetAfterID == 0 || nSheetID == 0) return;

	CArray<UINT, UINT> arKey;
	UINT nKey, nNewKey;
	D_MS_WORK_REC_SHEET* pSheet;
	D_MS_WORK_REC_SHEET* pSheetTemp;
	//���纻 ����
	if(!pBook->List.Lookup(nSheetID, pSheetTemp)) return;
	pSheet = new D_MS_WORK_REC_SHEET;  pSheet->Initialize();
	*pSheet = *pSheetTemp; 
	int nSize = pBook->GetKeyList(arKey);
	SortKeyList(arKey);

	nNewKey = nSheetAfterID+1;
	for(int i=nSize-1 ; i>=0 ; i--)
	{
		nKey = arKey.GetAt(i);
		if(nKey <= nSheetAfterID) continue;
		if(!pBook->List.Lookup(nKey, pSheetTemp)) continue;
		pBook->List.RemoveKey(nKey);
		pBook->List.SetAt(nKey+1, pSheetTemp);
		if(pBook->nActSheetID == nKey) pBook->nActSheetID = nKey+1;
	}	
	pBook->List.SetAt(nNewKey, pSheet);	
	return;
}

void CMSWorkRec::SetSheetName(CString sSheetNameOld, CString sSheetNameNew)
{
	if(!(m_nType == 1 || m_nType == 2)) return;

	D_MS_WORK_REC_BOOK* pBook;
	if(!m_BookMap.Lookup(m_nActBookID, pBook)) return;

	UINT nSheetID = Find_SheetID(sSheetNameOld);
	if(nSheetID == 0) return;
	D_MS_WORK_REC_SHEET* pSheet;
	if(pBook->List.Lookup(nSheetID, pSheet))
	{
		pSheet->strName = sSheetNameNew;
	}
}

CString CMSWorkRec::GetSheetName()
{
	if(!(m_nType == 1 || m_nType == 2)) return "";

	D_MS_WORK_REC_BOOK* pBook;
	if(!m_BookMap.Lookup(m_nActBookID, pBook)) return "";

	D_MS_WORK_REC_SHEET* pSheet;
	if(!pBook->List.Lookup(pBook->nActSheetID, pSheet)) return "";

	return pSheet->strName;
}

void CMSWorkRec::GetSheetsName(CStringArray& aSheets)
{
	aSheets.RemoveAll();

	if(!(m_nType == 1 || m_nType == 2)) return;

	D_MS_WORK_REC_BOOK* pBook;
	if(!m_BookMap.Lookup(m_nActBookID, pBook)) return;
	CArray<UINT, UINT> arKey;
	int nSize = pBook->GetKeyList(arKey);
	SortKeyList(arKey);

	aSheets.SetSize(nSize);
	D_MS_WORK_REC_SHEET* pSheet;
	for(int i=0 ; i<nSize ; i++)
	{
		if(pBook->List.Lookup(arKey.GetAt(i), pSheet))
			aSheets.SetAt(i, pSheet->strName);
		else 
			aSheets.SetAt(i, "");
	}
}

int CMSWorkRec::GetWorkSheetCount()
{
	if(!(m_nType == 1 || m_nType == 2)) return 0;

	D_MS_WORK_REC_BOOK* pBook;
	if(!m_BookMap.Lookup(m_nActBookID, pBook)) return 0;
	
	return pBook->List.GetCount();
}

BOOL CMSWorkRec::IsExistSheetName(CString strSheetName)
{
	if(!(m_nType == 1 || m_nType == 2)) return FALSE;

	return (Find_SheetID(strSheetName) > 0);
}
////////////////////////////////////////////////////////////

void CMSWorkRec::Add_WorkHistory(CString strHis)
{
	if(m_nType != 1) return;

	m_nCount++;
	m_WorkHistory.List.SetAt(m_nCount, strHis);	
}	

////////////////////////////////////////////////////////////

void CMSWorkRec::Add_SheetItem(UINT nRowNum, UINT nColNum, CString strItem)
{
	if(m_nType != 2) return;

	if(m_nActBookID == 0)
	{
		CString strName = "Book1";
		Add_Book(strName, TRUE);
	}		

	D_MS_WORK_REC_BOOK* pBook = NULL;
	if(m_BookMap.Lookup(m_nActBookID, pBook))
	{
		if(pBook->nActSheetID == 0)
		{
			CString strName = "Sheet1";
			Add_Sheet(strName, TRUE);
		}
		D_MS_WORK_REC_SHEET* pSheet = NULL;
		if(pBook->List.Lookup(pBook->nActSheetID, pSheet))
		{
			D_MS_WORK_REC_UNIT* pRecUnit = NULL;
			if(pSheet->List.Lookup(nRowNum, pRecUnit))
			{
				CString strTemp = "";
				if(pRecUnit->List.Lookup(nColNum, strTemp))
				{ if(strTemp != "")	strItem = strTemp + " // " + strItem;	}
				
				pRecUnit->List.SetAt(nColNum, strItem);			
			}
			else 
			{
				pRecUnit = new D_MS_WORK_REC_UNIT;
				pRecUnit->Initialize();
				pRecUnit->List.SetAt(nColNum, strItem);
				pSheet->List.SetAt(nRowNum, pRecUnit);
			}
		}
	}
}

void CMSWorkRec::Add_SheetItem(UINT nRowNum, UINT nColNum, double  dValue)
{
	CString strItem;
	strItem.Format("%g", dValue);
	Add_SheetItem(nRowNum, nColNum, strItem);
}
void CMSWorkRec::Add_SheetItem(UINT nRowNum, UINT nColNum, int nValue)
{
	CString strItem;
	strItem.Format("%d", nValue);
	Add_SheetItem(nRowNum, nColNum, strItem);
}

void CMSWorkRec::InsertCell(UINT nRow1, UINT nCol1, UINT nRow2, UINT nCol2, short iOpt)
{
	if(m_nType != 2) return;
	if(m_nActBookID == 0) return;

	D_MS_WORK_REC_BOOK* pBook;
	if(m_BookMap.Lookup(m_nActBookID, pBook))
	{
		if(pBook->nActSheetID == 0) return;
		D_MS_WORK_REC_SHEET* pSheet;
		if(pBook->List.Lookup(pBook->nActSheetID, pSheet))
		{
			UINT nTemp;
			if(nRow1 > nRow2) { nTemp=nRow1;  nRow1=nRow2;  nRow2=nTemp; }
			if(nCol1 > nCol2) { nTemp=nCol1;  nCol1=nCol2;  nCol2=nTemp; }
			int nShiftRow = nRow2 - nRow1 + 1;
			int nShiftCol = nCol2 - nCol1 + 1;
			// iOpt : �߰����(1:���������� �̵� 2:�Ʒ��� �̵� 3:�� ���� 4:�� ����)

			UINT nColKey, nRowKey, nRowKey2;
			D_MS_WORK_REC_UNIT* pRecTemp;
			D_MS_WORK_REC_UNIT* pRecTemp2;
			CString strValue;
			CArray<UINT, UINT> arColKey;
			CArray<UINT, UINT> arRowKey;
			int nColSize, nRowSize, i, j;
			
			// ���� (������ : �����̹Ƿ� key�� ū�� ���� ó���Ѵ�.)
			nRowSize = pSheet->GetKeyList(arRowKey);	
			SortKeyList(arRowKey);
			for(i=nRowSize-1 ; i>=0 ; i--)
			{
				nRowKey = arRowKey.GetAt(i);
				if(!pSheet->List.Lookup(nRowKey,pRecTemp)) continue;
				nColSize = pRecTemp->GetKeyList(arColKey);	
				SortKeyList(arColKey);
				if(iOpt == 1)
				{//1:���������� �̵�
					if(nRowKey < nRow1 || nRowKey > nRow2) continue;					
					for(j=nColSize-1 ; j>=0 ; j--)
					{
						nColKey = arColKey.GetAt(j);
						if(nColKey < nCol1) continue;

						if(pRecTemp->List.Lookup(nColKey, strValue))
						{
							pRecTemp->List.RemoveKey(nColKey);
							pRecTemp->List.SetAt(nColKey+nShiftCol, strValue);
						}
					}
				}
				else if(iOpt == 2)
				{//2:�Ʒ��� �̵�
					nRowKey2 = nRowKey+nShiftRow;
					if(!pSheet->List.Lookup(nRowKey2,pRecTemp2)) 
					{ pRecTemp2 = new D_MS_WORK_REC_UNIT;  pRecTemp2->Initialize();  pSheet->List.SetAt(nRowKey2,pRecTemp2); }
					if(nRowKey < nRow1) continue;
					for(j=nColSize-1 ; j>=0 ; j--)
					{
						nColKey = arColKey.GetAt(j);
						if(nColKey < nCol1 || nColKey > nCol2) continue;
						if(pRecTemp->List.Lookup(nColKey, strValue))
						{
							pRecTemp->List.RemoveKey(nColKey);
							pRecTemp2->List.SetAt(nColKey, strValue);
						}						
					}
				}
				else if(iOpt == 3)
				{//3:�� ����
					if(nRowKey < nRow1) continue;
					nRowKey2 = nRowKey+nShiftRow;
					pSheet->RemoveKey(nRowKey2);    // Data�� �����ϴ� ��� Data���� ��� �Ҹ�
					pSheet->List.RemoveKey(nRowKey);// Data�� �����ϰ� Key�� ����
					pSheet->List.SetAt(nRowKey2, pRecTemp);
				}
				else if(iOpt == 4)
				{//4:�� ����
					for(j=nColSize-1 ; j>=0 ; j--)
					{
						nColKey = arColKey.GetAt(j);
						if(nColKey < nCol1) continue;
						if(pRecTemp->List.Lookup(nColKey, strValue))
						{
							pRecTemp->List.RemoveKey(nColKey);
							pRecTemp->List.SetAt(nColKey+nShiftCol, strValue);
						}
					}
				}
				else ASSERT(0);				
			}		
			
			// Data�� �������� �ʴ� Row ����
			POSITION Pos = pSheet->List.GetStartPosition();
			arRowKey.RemoveAll();
			while(Pos)
			{
				pSheet->List.GetNextAssoc(Pos, nRowKey, pRecTemp);
				if(pRecTemp->List.GetCount() == 0) arRowKey.Add(nRowKey);				
			}
			nRowSize = arRowKey.GetSize();
			for(i=0 ; i<nRowSize ; i++)
			{ pSheet->RemoveKey(arRowKey.GetAt(i)); }
		}
	}	
}
void CMSWorkRec::DeletCell(UINT nRow1, UINT nCol1, UINT nRow2, UINT nCol2, short iOpt)
{
	if(m_nType != 2) return;
	if(m_nActBookID == 0) return;

	D_MS_WORK_REC_BOOK* pBook;
	if(m_BookMap.Lookup(m_nActBookID, pBook))
	{
		if(pBook->nActSheetID == 0) return;
		D_MS_WORK_REC_SHEET* pSheet;
		if(pBook->List.Lookup(pBook->nActSheetID, pSheet))
		{
			UINT nTemp;
			if(nRow1 > nRow2) { nTemp=nRow1;  nRow1=nRow2;  nRow2=nTemp; }
			if(nCol1 > nCol2) { nTemp=nCol1;  nCol1=nCol2;  nCol2=nTemp; }
			int nShiftRow = nRow2 - nRow1 + 1;
			int nShiftCol = nCol2 - nCol1 + 1;
			// iOpt : �߰����(1:�������� �̵� 2:���� �̵� 3:�� ���� 4:�� ����)

			UINT nColKey, nRowKey, nRowKey2;
			D_MS_WORK_REC_UNIT* pRecTemp;
			D_MS_WORK_REC_UNIT* pRecTemp2;
			CString strValue;
			CArray<UINT, UINT> arColKey;
			CArray<UINT, UINT> arRowKey;
			int nColSize, nRowSize, i, j;
			
			// Data����
			nRowSize = pSheet->GetKeyList(arRowKey);	
			SortKeyList(arRowKey);
			for(i=0 ; i<nRowSize ; i++)
			{
				nRowKey = arRowKey.GetAt(i);
				if(!pSheet->List.Lookup(nRowKey,pRecTemp)) continue;
				nColSize = pRecTemp->GetKeyList(arColKey);	
				SortKeyList(arColKey);
				if(iOpt == 1 || iOpt == 2)
				{//1:�������� �̵� 2:���� �̵�
					if(nRowKey < nRow1 || nRowKey > nRow2) continue;					
					for(j=0 ; j<nColSize ; j++)
					{
						nColKey = arColKey.GetAt(j);
						if(nColKey < nCol1 || nColKey > nCol2) continue;
						pRecTemp->List.RemoveKey(nColKey);
					}
				}
				else if(iOpt == 3)
				{//3:�� ����
					if(nRowKey < nRow1 || nRowKey > nRow2) continue;					
					pSheet->RemoveKey(nRowKey);
				}
				else if(iOpt == 4)
				{//4:�� ����
					for(j=0 ; j<nColSize ; j++)
					{
						nColKey = arColKey.GetAt(j);
						if(nColKey < nCol1 || nColKey > nCol2) continue;
						pRecTemp->List.RemoveKey(nColKey);
					}
				}
				else ASSERT(0);				
			}		

			// ������ ���ġ (������ : �����̹Ƿ� key�� ������ ���� ó���Ѵ�.)
			nRowSize = pSheet->GetKeyList(arRowKey);	
			SortKeyList(arRowKey);
			for(i=0 ; i<nRowSize ; i++)
			{
				nRowKey = arRowKey.GetAt(i);
				if(!pSheet->List.Lookup(nRowKey,pRecTemp)) continue;
				nColSize = pRecTemp->GetKeyList(arColKey);	
				SortKeyList(arColKey);
				if(iOpt == 1)
				{//1:�������� �̵�
					if(nRowKey < nRow1 || nRowKey > nRow2) continue;					
					for(j=0 ; j<nColSize ; j++)
					{
						nColKey = arColKey.GetAt(j);
						if(nColKey <= nCol2) continue;

						if(pRecTemp->List.Lookup(nColKey, strValue))
						{
							pRecTemp->List.RemoveKey(nColKey);
							pRecTemp->List.SetAt(nColKey-nShiftCol, strValue);
						}
					}
				}
				else if(iOpt == 2)
				{//2:���� �̵�
					nRowKey2 = nRowKey-nShiftRow;
					if(!pSheet->List.Lookup(nRowKey2,pRecTemp2)) 
					{ pRecTemp2 = new D_MS_WORK_REC_UNIT;  pRecTemp2->Initialize();  pSheet->List.SetAt(nRowKey2,pRecTemp2); }
					if(nRowKey <= nRow2) continue;
					for(j=0 ; j<nColSize ; j++)
					{
						nColKey = arColKey.GetAt(j);
						if(nColKey < nCol1 || nColKey > nCol2) continue;
						if(pRecTemp->List.Lookup(nColKey, strValue))
						{
							pRecTemp->List.RemoveKey(nColKey);
							pRecTemp2->List.SetAt(nColKey, strValue);
						}						
					}
				}
				else if(iOpt == 3)
				{//3:�� ����
					if(nRowKey <= nRow2) continue;
					nRowKey2 = nRowKey-nShiftRow;
					pSheet->RemoveKey(nRowKey2);    // Data�� �����ϴ� ��� Data���� ��� �Ҹ�
					pSheet->List.RemoveKey(nRowKey);// Data�� �����ϰ� Key�� ����
					pSheet->List.SetAt(nRowKey2, pRecTemp);
				}
				else if(iOpt == 4)
				{//4:�� ����
					for(j=nColSize-1 ; j>=0 ; j--)
					{
						nColKey = arColKey.GetAt(j);
						if(nColKey <= nCol2) continue;
						if(pRecTemp->List.Lookup(nColKey, strValue))
						{
							pRecTemp->List.RemoveKey(nColKey);
							pRecTemp->List.SetAt(nColKey-nShiftCol, strValue);
						}
					}
				}
				else ASSERT(0);				
			}		
			
			// Data�� �������� �ʴ� Row ����
			POSITION Pos = pSheet->List.GetStartPosition();
			arRowKey.RemoveAll();
			while(Pos)
			{
				pSheet->List.GetNextAssoc(Pos, nRowKey, pRecTemp);
				if(pRecTemp->List.GetCount() == 0) arRowKey.Add(nRowKey);				
			}
			nRowSize = arRowKey.GetSize();
			for(i=0 ; i<nRowSize ; i++)
			{ pSheet->RemoveKey(arRowKey.GetAt(i)); }
		}
	}	
}

void CMSWorkRec::Clear(UINT nRow1, UINT nCol1, UINT nRow2, UINT nCol2)
{
	if(m_nType != 2) return;
	if(m_nActBookID == 0) return;

	D_MS_WORK_REC_BOOK* pBook;
	if(m_BookMap.Lookup(m_nActBookID, pBook))
	{
		if(pBook->nActSheetID == 0) return;
		D_MS_WORK_REC_SHEET* pSheet;
		if(pBook->List.Lookup(pBook->nActSheetID, pSheet))
		{
			UINT nTemp;
			if(nRow1 > nRow2) { nTemp=nRow1;  nRow1=nRow2;  nRow2=nTemp; }
			if(nCol1 > nCol2) { nTemp=nCol1;  nCol1=nCol2;  nCol2=nTemp; }
			int nShiftRow = nRow2 - nRow1 + 1;
			int nShiftCol = nCol2 - nCol1 + 1;
			// iOpt : �߰����(1:���������� �̵� 2:�Ʒ��� �̵� 3:�� ���� 4:�� ����)

			UINT nColKey, nRowKey;
			D_MS_WORK_REC_UNIT* pRecTemp;
			CString strValue;
			CArray<UINT, UINT> arColKey;
			CArray<UINT, UINT> arRowKey;
			int nColSize, nRowSize, i, j;
						
			nRowSize = pSheet->GetKeyList(arRowKey);	
			SortKeyList(arRowKey);
			for(i=0 ; i<nRowSize ; i++)
			{
				nRowKey = arRowKey.GetAt(i);
				if(!pSheet->List.Lookup(nRowKey,pRecTemp)) continue;
				nColSize = pRecTemp->GetKeyList(arColKey);	
				SortKeyList(arColKey);
				
				if(nRowKey < nRow1 || nRowKey > nRow2) continue;					
				for(j=nColSize-1 ; j>=0 ; j--)
				{
					nColKey = arColKey.GetAt(j);
					if(nColKey < nCol1 || nColKey > nCol2) continue;
					pRecTemp->List.RemoveKey(nColKey);
				}		
			}		
			
			// Data�� �������� �ʴ� Row ����
			POSITION Pos = pSheet->List.GetStartPosition();
			arRowKey.RemoveAll();
			while(Pos)
			{
				pSheet->List.GetNextAssoc(Pos, nRowKey, pRecTemp);
				if(pRecTemp->List.GetCount() == 0) arRowKey.Add(nRowKey);				
			}
			nRowSize = arRowKey.GetSize();
			for(i=0 ; i<nRowSize ; i++)
			{ pSheet->RemoveKey(arRowKey.GetAt(i)); }
		}
	}	
}

BOOL CMSWorkRec::GetValue(UINT nRowNum, UINT nColNum, CString& strItem)
{
	if(m_nType != 2) return FALSE;
	if(m_nActBookID == 0) return FALSE;
	D_MS_WORK_REC_BOOK*  pBook;
	D_MS_WORK_REC_SHEET* pSheet;
	D_MS_WORK_REC_UNIT*  pRecUnit;
	
	if(!m_BookMap.Lookup(m_nActBookID, pBook)) return FALSE;
	if(!pBook->List.Lookup(pBook->nActSheetID, pSheet)) return FALSE;
	if(!pSheet->List.Lookup(nRowNum, pRecUnit)) return FALSE;
	if(!pRecUnit->List.Lookup(nColNum, strItem)) return FALSE;
	return TRUE;
}

UINT CMSWorkRec::Find_BookID(CString strBookName)
{
	if(!(m_nType == 1 || m_nType == 2)) return 0;
	if(m_BookMap.GetCount() == 0) return 0;
	
	UINT nKey;
	D_MS_WORK_REC_BOOK* pBook;
	POSITION Pos = m_BookMap.GetStartPosition();	
	while(Pos)
	{	
		m_BookMap.GetNextAssoc(Pos,nKey,pBook);
		if(pBook->strName == strBookName)
			return nKey;		
	}
	return 0;
}

UINT CMSWorkRec::Find_SheetID(CString strSheetName)
{
	if(!(m_nType == 1 || m_nType == 2)) return 0;
	if(m_BookMap.GetCount() == 0) return 0;

	D_MS_WORK_REC_BOOK* pBook;
	if(m_BookMap.Lookup(m_nActBookID, pBook))
	{		
		UINT nKey;
		D_MS_WORK_REC_SHEET* pSheet;
		POSITION Pos = pBook->List.GetStartPosition();	
		while(Pos)
		{	
			pBook->List.GetNextAssoc(Pos,nKey,pSheet);
			if(pSheet->strName == strSheetName)
				return nKey;		
		}
	}
	return 0;
}

int CMSWorkRec::GetSheetKeyList(CArray<UINT, UINT>& arKey)
{
	if(!(m_nType == 1 || m_nType == 2)) return 0;
	arKey.RemoveAll();

	if(m_BookMap.GetCount() == 0) return 0;

	D_MS_WORK_REC_BOOK* pBook;
	if(m_BookMap.Lookup(m_nActBookID, pBook))
	{	
		int nCount = pBook->List.GetCount();
		if(nCount == 0) return 0;
		arKey.SetSize(nCount);

		nCount = 0;
		UINT nKey;
		D_MS_WORK_REC_SHEET* pRecTemp;		
		POSITION Pos = pBook->List.GetStartPosition();	
		while(Pos)
		{	
			pBook->List.GetNextAssoc(Pos,nKey,pRecTemp);
			arKey.SetAt(nCount, nKey);
			nCount++;		
		}
		return arKey.GetSize();
	}
	return 0;
}

void CMSWorkRec::SortKeyList(CArray<UINT, UINT>& arKey)
{
	int nSize = arKey.GetSize();
	int i, j;
	UINT tempKey;
	for(i=0 ; i<nSize-1 ; i++)
	{
		for(j=i+1 ; j<nSize ; j++)
		{
			if(arKey[i] > arKey[j])
			{
				tempKey = arKey[i];
				arKey[i] = arKey[j];
				arKey[j] = tempKey;
			}
		}
	}
}
void CMSWorkRec::DestroySheetMap()
{
	if(m_BookMap.GetCount() == 0) return;
	
	UINT nKey;
	D_MS_WORK_REC_BOOK* pBook;
	POSITION Pos = m_BookMap.GetStartPosition();	
	while(Pos)
	{	
		m_BookMap.GetNextAssoc(Pos,nKey,pBook);
		pBook->DestroyItem();
		delete pBook;
	}
	m_BookMap.RemoveAll();
}
